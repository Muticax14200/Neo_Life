-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 17 juil. 2020 à 21:58
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `neo`
--

-- --------------------------------------------------------

--
-- Structure de la table `banking_account`
--

CREATE TABLE `banking_account` (
  `id` int(11) NOT NULL,
  `label` varchar(50) NOT NULL DEFAULT '0',
  `uuid` varchar(255) NOT NULL DEFAULT '0',
  `coowner` longtext DEFAULT NULL,
  `amount` int(11) NOT NULL DEFAULT 0,
  `iban` longtext DEFAULT NULL,
  `todayratio` varchar(255) DEFAULT '{"remove":0,"deposit":0,"maxRemove":5000,"maxDeposit":5000}'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `banking_account`
--


-- --------------------------------------------------------

--
-- Structure de la table `phone_app_chat`
--

CREATE TABLE `phone_app_chat` (
  `id` int(11) NOT NULL,
  `channel` varchar(20) NOT NULL,
  `message` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `phone_app_chat`
--


-- --------------------------------------------------------

--
-- Structure de la table `phone_calls`
--

CREATE TABLE `phone_calls` (
  `id` int(11) NOT NULL,
  `owner` varchar(10) NOT NULL COMMENT 'Num tel proprio',
  `num` varchar(10) NOT NULL COMMENT 'Num reférence du contact',
  `incoming` int(11) NOT NULL COMMENT 'Défini si on est à l''origine de l''appels',
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `accepts` int(11) NOT NULL COMMENT 'Appels accepter ou pas'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `phone_calls`
--

CREATE TABLE `phone_messages` (
  `id` int(11) NOT NULL,
  `transmitter` varchar(10) NOT NULL,
  `receiver` varchar(10) NOT NULL,
  `message` varchar(255) NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `isRead` int(11) NOT NULL DEFAULT 0,
  `owner` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `phone_users_contacts` (
  `id` int(11) NOT NULL,
  `identifier` varchar(60) CHARACTER SET utf8mb4 DEFAULT NULL,
  `number` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `display` varchar(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '-1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `phone_users_contacts`
--

INSERT INTO `phone_users_contacts` (`id`, `identifier`, `number`, `display`) VALUES
(1, 'steam:11000013448593d', '5556842', 'Pierre Eric Calend'),
(2, 'steam:11000011c152acd', '555183', '41 - Matt'),
(3, 'steam:1100001402bb099', '5551960', 'Natsuki Watson'),
(4, 'steam:1100001402bb099', '5552825', 'Matthieu Kiwi'),
(5, 'steam:110000119d4c86b', '5551560', 'Thomas Jonhson (PDM)'),
(6, 'steam:11000013448593d', '5551560', 'Thomas Johnson'),
(7, 'steam:1100001402bb099', '5556842', 'P.E Calend'),
(8, 'steam:11000011c152acd', '5551560', '95 - Thomas'),
(9, 'steam:110000136ab7e4f', '5554836', 'Billy'),
(10, 'steam:1100001402bb099', '5551376', 'Mehdi Taiga'),
(11, 'steam:1100001402bb099', '5553462', 'Jason Dave'),
(24, 'steam:11000011b0ba5c2', '5551960', 'Natsuki Watson '),
(23, 'steam:11000011b0ba5c2', '5551560', 'Thomas Jonhson'),
(14, 'steam:110000114d36f7e', '5551560', ' directeur generale du concess'),
(15, 'steam:1100001402bb099', '5558423', 'Franck Madrazo'),
(16, 'steam:11000013448593d', '5558423', 'Bucheron Madrazo'),
(17, 'steam:11000013448593d', '5556582', 'Shito Suzuki'),
(18, 'steam:110000134194493', '5552825', 'Matthieu Kiwi'),
(19, 'steam:110000119d4c86b', '5551083', 'Mr.Kiwi'),
(20, 'steam:11000010c2786df', '5553462', 'Nouveau Contact'),
(21, 'steam:11000010c2786df', '5558423', 'Nouveau Contact'),
(22, 'steam:110000110b1ecee', '555183', 'Matthieu Kiwi'),
(25, 'steam:11000011b0ba5c2', '5559689', 'Eliko Argwinn'),
(26, 'steam:11000013448593d', '5559689', 'Patron Benny\'s'),
(27, 'steam:110000110b1ecee', '5553462', 'Jason Dave'),
(28, 'steam:11000013448593d', '5553462', 'MrDave'),
(44, 'steam:11000013448593d', '55553927', 'Rodriguez Hernandez'),
(30, 'steam:11000010aed1260', '5558423', 'Madraso PDG'),
(31, 'steam:110000114d36f7e', '5556184', 'David Camora'),
(32, 'steam:110000114d36f7e', '5557993', 'Yacine Kherat'),
(33, 'steam:110000114d36f7e', '5553927', 'Rodriguez hernandez'),
(34, 'steam:11000010de74d29', '5553462', 'Dave'),
(35, 'steam:11000010de74d29', '555671', 'Eliko'),
(38, 'steam:11000010de74d29', '5551560', 'Thomas'),
(39, 'steam:11000010de74d29', '5551960', 'Natsuki'),
(40, 'steam:1100001402bb099', '5553927', 'Rodriguez Hernandez'),
(41, 'steam:11000011c152acd', '5559689', 'Arguin - Benny\'s'),
(42, 'steam:11000010de74d29', '5556842', 'P.Khalene'),
(43, 'steam:11000010de74d29', '555183', 'Matthieu Kiwi'),
(45, 'steam:11000013448593d', '5551960', 'Natsuki (doit 575)'),
(46, 'steam:11000010de74d29', '5558423', 'Franck'),
(47, 'steam:110000114d36f7e', '5551960', 'Natsuki'),
(48, 'steam:11000011918f8b8', '5557993', 'Nouveau Contact'),
(49, 'steam:11000011b0ba5c2', '5552825', 'Matthieu Kiwi Mécano'),
(50, 'steam:110000134194493', '5551960', 'Nustuki Watson'),
(51, 'steam:11000011b0ba5c2', '5556582', 'Shito Suzuki'),
(52, 'steam:110000134194493', '5553462', 'Jason Dave (Patron M)'),
(53, 'steam:1100001402bb099', '5556582', 'Shito Suzuki'),
(54, 'steam:11000013448593d', '5556929', 'Watterson'),
(55, 'steam:11000011c152acd', '5556929', '55'),
(56, 'steam:110000134194493', '5551560', 'Thomas Jonhson'),
(57, 'steam:110000119d4c86b', '5555879', 'Rodriguez'),
(58, 'steam:110000110b1ecee', '5551960', 'Natsuki Waston'),
(59, 'steam:110000114d36f7e', '5558279', 'Patron vigneron'),
(60, 'steam:11000013448593d', '5558279', 'Patronne Bucheron'),
(61, 'steam:1100001402bb099', '5558279', 'Vigneron'),
(62, 'steam:11000013dbf7690', '5552825', 'Mécano 1'),
(63, 'steam:110000110b1ecee', '555', 'Mme Vigneron'),
(64, 'steam:11000011b0ba5c2', '5558279', 'Carter'),
(65, 'steam:110000119d4c86b', '5553462', 'Jason Dave'),
(66, 'steam:110000119d4c86b', '5558279', 'Ivy Carter'),
(67, 'steam:1100001111e48d8', '55553462', 'Jason Dave'),
(68, 'steam:1100001111e48d8', '5553462', 'JasonDave2');

-- --------------------------------------------------------

--
-- Structure de la table `players_appartement`
--

CREATE TABLE `players_appartement` (
  `id` int(11) NOT NULL,
  `capacity` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `pos` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `indexx` int(11) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `coowner` text DEFAULT NULL,
  `table_index` int(11) DEFAULT NULL,
  `time` bigint(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `players_appearance`
--

CREATE TABLE `players_appearance` (
  `id` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL DEFAULT 'mp_m_freemode_01',
  `face` text DEFAULT NULL,
  `outfit` text DEFAULT NULL,
  `tattoo` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `players_computer_accounts` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `perms` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `players_identity`
--

CREATE TABLE `players_identity` (
  `id` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `face_picutre` text NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `birth_date` text NOT NULL,
  `origine` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `players_inventory` (
  `id` int(11) NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `data` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE `players_jobs` (
  `id` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `name` text NOT NULL,
  `rank` int(11) NOT NULL,
  `orga` text DEFAULT NULL,
  `orga_rank` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `players_parking` (
  `id` int(11) NOT NULL,
  `garage` varchar(50) NOT NULL DEFAULT '0',
  `vehicles` longtext NOT NULL,
  `uuid` varchar(255) NOT NULL DEFAULT '0',
  `label` varchar(50) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE `players_settings` (
  `id` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `bind` text NOT NULL,
  `colors` text NOT NULL,
  `outfit` text NOT NULL,
  `farm_limit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `players_vehicles`
--

CREATE TABLE `players_vehicles` (
  `id` int(11) NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `settings` longtext DEFAULT NULL,
  `pound` tinyint(1) DEFAULT 0,
  `label` varchar(50) DEFAULT NULL,
  `plate` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `players_weapon` (
  `id` int(11) NOT NULL,
  `serial` int(11) NOT NULL DEFAULT 0,
  `weapon_name` varchar(50) NOT NULL DEFAULT '0',
  `user` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `storages_inventory_accounts` (
  `id` int(11) NOT NULL,
  `money` int(11) NOT NULL DEFAULT 0,
  `dark_money` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0,
  `name` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE `storages_inventory_items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `itemName` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `metadata` varchar(255) COLLATE utf8mb4_bin DEFAULT '{}',
  `label` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



CREATE TABLE `twitter_accounts` (
  `id` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `password` varchar(50) COLLATE utf8mb4_bin NOT NULL DEFAULT '0',
  `avatar_url` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
--
-- Structure de la table `twitter_likes`
--

CREATE TABLE `twitter_likes` (
  `id` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `tweetId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Structure de la table `twitter_tweets`
--

CREATE TABLE `twitter_tweets` (
  `id` int(11) NOT NULL,
  `authorId` int(11) NOT NULL,
  `realUser` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `likes` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `identifier` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `food` int(11) DEFAULT 100,
  `thirst` int(11) DEFAULT 100,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `money` int(11) DEFAULT 1500,
  `black_money` int(11) DEFAULT 0,
  `permission_level` int(11) DEFAULT 0,
  `xp` int(11) DEFAULT 0,
  `group` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `phone_number` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL,
  `character_count` int(11) NOT NULL,
  `character_limit` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Index pour la table `banking_account`
--
ALTER TABLE `banking_account`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `phone_app_chat`
--
ALTER TABLE `phone_app_chat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `phone_calls`
--
ALTER TABLE `phone_calls`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `phone_messages`
--
ALTER TABLE `phone_messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `phone_users_contacts`
--
ALTER TABLE `phone_users_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_appartement`
--
ALTER TABLE `players_appartement`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `players_appearance`
--
ALTER TABLE `players_appearance`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_computer_accounts`
--
ALTER TABLE `players_computer_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_identity`
--
ALTER TABLE `players_identity`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_inventory`
--
ALTER TABLE `players_inventory`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_jobs`
--
ALTER TABLE `players_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_parking`
--
ALTER TABLE `players_parking`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_settings`
--
ALTER TABLE `players_settings`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_vehicles`
--
ALTER TABLE `players_vehicles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `players_weapon`
--
ALTER TABLE `players_weapon`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Index pour la table `storages_inventory_accounts`
--
ALTER TABLE `storages_inventory_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `storages_inventory_items`
--
ALTER TABLE `storages_inventory_items`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `twitter_accounts`
--
ALTER TABLE `twitter_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Index pour la table `twitter_likes`
--
ALTER TABLE `twitter_likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_twitter_likes_twitter_accounts` (`authorId`),
  ADD KEY `FK_twitter_likes_twitter_tweets` (`tweetId`);

--
-- Index pour la table `twitter_tweets`
--
ALTER TABLE `twitter_tweets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_twitter_tweets_twitter_accounts` (`authorId`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `banking_account`
--
ALTER TABLE `banking_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT pour la table `phone_app_chat`
--
ALTER TABLE `phone_app_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `phone_calls`
--
ALTER TABLE `phone_calls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=974;

--
-- AUTO_INCREMENT pour la table `phone_messages`
--
ALTER TABLE `phone_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=496;

--
-- AUTO_INCREMENT pour la table `phone_users_contacts`
--
ALTER TABLE `phone_users_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT pour la table `players_appartement`
--
ALTER TABLE `players_appartement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `players_appearance`
--
ALTER TABLE `players_appearance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT pour la table `players_computer_accounts`
--
ALTER TABLE `players_computer_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `players_identity`
--
ALTER TABLE `players_identity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT pour la table `players_inventory`
--
ALTER TABLE `players_inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7079;

--
-- AUTO_INCREMENT pour la table `players_jobs`
--
ALTER TABLE `players_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT pour la table `players_parking`
--
ALTER TABLE `players_parking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=173;

--
-- AUTO_INCREMENT pour la table `players_settings`
--
ALTER TABLE `players_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `players_vehicles`
--
ALTER TABLE `players_vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `players_weapon`
--
ALTER TABLE `players_weapon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `storages_inventory_accounts`
--
ALTER TABLE `storages_inventory_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT pour la table `storages_inventory_items`
--
ALTER TABLE `storages_inventory_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5146;

--
-- AUTO_INCREMENT pour la table `twitter_accounts`
--
ALTER TABLE `twitter_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `twitter_likes`
--
ALTER TABLE `twitter_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT pour la table `twitter_tweets`
--
ALTER TABLE `twitter_tweets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `twitter_likes`
--
ALTER TABLE `twitter_likes`
  ADD CONSTRAINT `FK_twitter_likes_twitter_accounts` FOREIGN KEY (`authorId`) REFERENCES `twitter_accounts` (`id`),
  ADD CONSTRAINT `FK_twitter_likes_twitter_tweets` FOREIGN KEY (`tweetId`) REFERENCES `twitter_tweets` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `twitter_tweets`
--
ALTER TABLE `twitter_tweets`
  ADD CONSTRAINT `FK_twitter_tweets_twitter_accounts` FOREIGN KEY (`authorId`) REFERENCES `twitter_accounts` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
