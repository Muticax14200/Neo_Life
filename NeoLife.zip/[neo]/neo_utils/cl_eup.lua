----NJD SCRIPTS
--------THIS WAS MODIFED BY NJD AND R41ND4Y5 
----------Version 1.0
local outfits = {
	['Male LSCoFD Bunker Pants'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 74, 17 },
			{ 3, 1, 1 },
			{ 10, 1, 1 },
			{ 8, 16, 1 },
			{ 4, 20, 1 },
			{ 6, 52, 1 },
			{ 7, 19, 1 },
			{ 9, 1, 1 },
			{ 5, 1, 1 },
		}
	},
	['Male LSCoFD Turnouts'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 81, 2 },
			{ 3, 97, 1 },
			{ 10, 18, 1 },
			{ 8, 16, 1 },
			{ 4, 44, 2 },
			{ 6, 14, 1 },
			{ 7, 1, 1 },
			{ 9, 1, 1 },
			{ 5, 49, 1 },
		}
	},
	['Male LSCoFD PPE Gear'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 46, 4 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 78, 2 },
			{ 3, 97, 1 },
			{ 10, 18, 1 },
			{ 8, 69, 1 },
			{ 4, 44, 2 },
			{ 6, 14, 1 },
			{ 7, 46, 2 },
			{ 9, 1, 1 },
			{ 5, 49, 1 },
		}
	},
	['Female LSCoFD Bunker Pants'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 225, 23 },
			{ 3, 15, 1 },
			{ 10, 1, 1 },
			{ 8, 15, 1 },
			{ 4, 49, 1 },
			{ 6, 53, 1 },
			{ 7, 13, 1 },
			{ 9, 1, 1 },
			{ 5, 49, 1 },
		}
	},
	['Female LSCoFD Turnouts'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 74, 2 },
			{ 3, 112, 1 },
			{ 10, 17, 1 },
			{ 8, 15, 1 },
			{ 4, 19, 2 },
			{ 6, 29, 1 },
			{ 7, 1, 1 },
			{ 9, 1, 1 },
			{ 5, 49, 1 },
		}
	},
	['Female LSCoFD PPE Gear'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 45, 4 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 65, 2 },
			{ 3, 112, 1 },
			{ 10, 17, 1 },
			{ 8, 49, 1 },
			{ 4, 19, 2 },
			{ 6, 29, 1 },
			{ 7, 33, 2 },
			{ 9, 1, 1 },
			{ 5, 49, 1 },
		}
	},
	['Male LSCoFD Fireman Class A'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 119, 3 },
			{ 3, 5, 1 },
			{ 10, 1, 1 },
			{ 8, 89, 1 },
			{ 4, 26, 4 },
			{ 6, 52, 1 },
			{ 7, 1, 1 },
			{ 9, 1, 1 },
			{ 5, 38, 2 },
		}
	},
	['Male LSCoFD Fireman Class B'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 76, 3 },
			{ 3, 5, 1 },
			{ 10, 1, 1 },
			{ 8, 89, 1 },
			{ 4, 26, 4 },
			{ 6, 52, 1 },
			{ 7, 1, 1 },
			{ 9, 1, 1 },
			{ 5, 38, 2 },
		}
	},
	['Male LSCoFD Fireman Class C'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 75, 3 },
			{ 3, 1, 1 },
			{ 10, 1, 1 },
			{ 8, 89, 1 },
			{ 4, 26, 4 },
			{ 6, 52, 1 },
			{ 7, 1, 1 },
			{ 9, 1, 1 },
			{ 5, 38, 2 },
		}
	},
	['Female LSCoFD Fireman Class A'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 19, 3 },
			{ 3, 4, 1 },
			{ 10, 1, 1 },
			{ 8, 8, 1 },
			{ 4, 42, 4 },
			{ 6, 53, 1 },
			{ 7, 1, 1 },
			{ 9, 1, 1 },
			{ 5, 38, 2 },
		}
	},
	['Female LSCoFD Fireman Class B'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 27, 4 },
			{ 3, 4, 1 },
			{ 10, 1, 1 },
			{ 8, 8, 1 },
			{ 4, 42, 4 },
			{ 6, 53, 1 },
			{ 7, 1, 1 },
			{ 9, 1, 1 },
			{ 5, 38, 2 },
		}
	},
	['Female LSCoFD Fireman Class C'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 26, 4 },
			{ 3, 15, 1 },
			{ 10, 1, 1 },
			{ 8, 8, 1 },
			{ 4, 42, 4 },
			{ 6, 53, 1 },
			{ 7, 1, 1 },
			{ 9, 1, 1 },
			{ 5, 38, 2 },
		}
	},
	['Male LSCoFD EMT Class B'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 76, 4 },
			{ 3, 87, 1 },
			{ 10, 1, 1 },
			{ 8, 55, 1 },
			{ 4, 87, 13 },
			{ 6, 52, 1 },
			{ 7, 31, 2 },
			{ 9, 1, 1 },
			{ 5, 38, 1 },
		}
	},
	['Male LSCoFD EMT Class C'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 75, 4 },
			{ 3, 86, 1 },
			{ 10, 1, 1 },
			{ 8, 55, 1 },
			{ 4, 87, 13 },
			{ 6, 52, 1 },
			{ 7, 31, 2 },
			{ 9, 30, 1 },
			{ 5, 38, 1 },
		}
	},
	['Male LSCoFD T-Shirt'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 24, 1 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 74, 17 },
			{ 3, 86, 1 },
			{ 10, 1, 1 },
			{ 8, 55, 1 },
			{ 4, 87, 13 },
			{ 6, 52, 1 },
			{ 7, 1, 1 },
			{ 9, 30, 1 },
			{ 5, 1, 1 },
		}
	},
	['Female LSCoFD EMT Class B'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 27, 3 },
			{ 3, 102, 1 },
			{ 10, 1, 1 },
			{ 8, 7, 1 },
			{ 4, 42, 4 },
			{ 6, 53, 1 },
			{ 7, 15, 1 },
			{ 9, 1, 1 },
			{ 5, 38, 1 },
		}
	},
	['Female LSCoFD EMT Class C'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 26, 3 },
			{ 3, 110, 1 },
			{ 10, 1, 1 },
			{ 8, 7, 1 },
			{ 4, 42, 4 },
			{ 6, 53, 1 },
			{ 7, 15, 1 },
			{ 9, 34, 1 },
			{ 5, 38, 1 },
		}
	},
	['Female LSCoFD T-Shirt'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 225, 23 },
			{ 3, 110, 1 },
			{ 10, 1, 1 },
			{ 8, 7, 1 },
			{ 4, 90, 13 },
			{ 6, 53, 1 },
			{ 7, 1, 1 },
			{ 9, 34, 1 },
			{ 5, 49, 1 },
		}
	},
	['Male LSCoFD Jacket'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 152, 4 },
			{ 3, 5, 1 },
			{ 10, 1, 1 },
			{ 8, 66, 7 },
			{ 4, 26, 4 },
			{ 6, 52, 1 },
			{ 7, 1, 1 },
			{ 9, 2, 1 },
			{ 5, 49, 1 },
		}
	},
	['Female LSCoFD Jacket'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 149, 4 },
			{ 3, 4, 1 },
			{ 10, 1, 1 },
			{ 8, 46, 7 },
			{ 4, 42, 4 },
			{ 6, 53, 1 },
			{ 7, 1, 1 },
			{ 9, 2, 1 },
			{ 5, 49, 1 },
		}
	},
	['Male LSCoFD Winter Jacket'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 3, 2 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 250, 2 },
			{ 3, 32, 1 },
			{ 10, 59, 2 },
			{ 8, 16, 1 },
			{ 4, 87, 13 },
			{ 6, 52, 1 },
			{ 7, 127, 1 },
			{ 9, 1, 1 },
			{ 5, 49, 1 },
		}
	},
	['Female LSCoFD Winter Jacket'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 6, 3 },
			{ 1, 0, 0 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 258, 2 },
			{ 3, 37, 1 },
			{ 10, 67, 2 },
			{ 8, 15, 1 },
			{ 4, 42, 4 },
			{ 6, 53, 1 },
			{ 7, 97, 1 },
			{ 9, 1, 1 },
			{ 5, 1, 1 },
		}
	},
	['Male LSCoFD Water Rescue'] = {
		category = 'LSCoFD',
		ped = 'mp_m_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 24, 1 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 74, 17 },
			{ 3, 1, 1 },
			{ 10, 1, 1 },
			{ 8, 89, 1 },
			{ 4, 87, 13 },
			{ 6, 3, 1 },
			{ 7, 1, 1 },
			{ 9, 26, 5 },
			{ 5, 1, 1 },
		}
	},
	['Female LSCoFD Water Rescue'] = {
		category = 'LSCoFD',
		ped = 'mp_f_freemode_01',
		props = {
			{ 0, 0, 0 },
			{ 1, 26, 1 },
			{ 2, 0, 0 },
			{ 6, 0, 0 },
		},
		components = {
			{ 1, 1, 1 },
			{ 11, 26, 4 },
			{ 3, 15, 1 },
			{ 10, 1, 1 },
			{ 8, 8, 1 },
			{ 4, 90, 13 },
			{ 6, 26, 1 },
			{ 7, 1, 1 },
			{ 9, 28, 5 },
			{ 5, 49, 1 },
		}
	}
}

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, 318) then 
            CreateMenu(menu)
        end
    end
end)

local function setOutfit(outfit)
    local ped = PlayerPedId()

    RequestModel(outfit.ped)

    while not HasModelLoaded(outfit.ped) do
        Wait(0)
    end

    if GetEntityModel(ped) ~= GetHashKey(outfit.ped) then
        SetPlayerModel(PlayerId(), outfit.ped)
    end

    ped = PlayerPedId()

    for _, comp in ipairs(outfit.components) do
       SetPedComponentVariation(ped, comp[1], comp[2] - 1, comp[3] - 1, 0)
    end

    for _, comp in ipairs(outfit.props) do
        if comp[2] == 0 then
            ClearPedProp(ped, comp[1])
        else
            SetPedPropIndex(ped, comp[1], comp[2] - 1, comp[3] - 1, true)
        end
    end
end

local categoryOutfits = {}

for name, outfit in pairs(outfits) do
    if not categoryOutfits[outfit.category] then
        categoryOutfits[outfit.category] = {}
    end

    categoryOutfits[outfit.category][name] = outfit
end

local menuPool = NativeUI.CreatePool()
local mainMenu = NativeUI.CreateMenu("Vestiaire", "Choisissez une catégorie")

for name, list in pairs(categoryOutfits) do
    local subMenu = menuPool:AddSubMenu(mainMenu, name)

    for id, outfit in pairs(list) do
        outfit.item = NativeUI.CreateItem(id, 'Séléctionnez une tenue')
        subMenu:AddItem(outfit.item)
    end

    subMenu.OnItemSelect = function(sender, item, index)
        -- find the outfit
        for _, outfit in pairs(list) do
            if outfit.item == item then
                CreateThread(function()
                    setOutfit(outfit)
                end)
            end
        end
    end
end

menuPool:Add(mainMenu)

menuPool:RefreshIndex()

menuPool:MouseControlsEnabled (false);
menuPool:MouseEdgeEnabled (false);
menuPool:ControlDisablingEnabled(false);

positions = {
    {{335.93, -580.45, 28.79, 0}, {335.93, -580.45, 28.79, 0},{36,237,157}, "First Teleport"},
}

key_to_teleport = 38

local player = GetPlayerPed(-1)

CreateThread(function ()
	while true do
		Wait(0)
		local player = GetPlayerPed(-1)
		local playerLoc = GetEntityCoords(player)
		for _,location in ipairs(positions) do
            teleport_text = location[4]
            loc1 = {
                x=location[1][1],
                y=location[1][2],
                z=location[1][3],
                heading=location[1][4]
            }
            loc2 = {
                x=location[2][1],
                y=location[2][2],
                z=location[2][3],
                heading=location[2][4]
            }
            Red = location[3][1]
            Green = location[3][2]
            Blue = location[3][3]
		
			DrawMarker(1, loc1.x, loc1.y, loc1.z, 0, 0, 0, 0, 0, 0, 1.501, 1.5001, 0.5001, Red, Green, Blue, 200, 0, 0, 0, 0)
			if CheckPos(playerLoc.x, playerLoc.y, playerLoc.z, loc1.x, loc1.y, loc1.z, 2) then 
				
				if IsControlJustReleased(1, key_to_teleport) then
					mainMenu:Visible(not mainMenu:Visible())
				end

			elseif CheckPos(playerLoc.x, playerLoc.y, playerLoc.z, loc2.x, loc2.y, loc2.z, 2) then
				if IsControlJustReleased(1, key_to_teleport) then
					mainMenu:Visible(not mainMenu:Visible())
				end
			end
		end
	end
end)

function CheckPos(x, y, z, cx, cy, cz, radius)
    local t1 = x - cx
    local t12 = t1^2

    local t2 = y-cy
    local t21 = t2^2

    local t3 = z - cz
    local t31 = t3^2

    return (t12 + t21 + t31) <= radius^2
end

CreateThread(function()
    while true do
		Wait(0)
        menuPool:ProcessMenus()
    end
end)