function SetData()
	players = {}
	for _, player in ipairs(GetActivePlayers()) do
		local ped = GetPlayerPed(player)
		table.insert( players, player )
end

	
	local name = GetPlayerName(PlayerId())
	local id = GetPlayerServerId(PlayerId())
	Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), 'FE_THDR_GTAO', '~b~NEO ~t~| ~b~ID : ~w~' .. id .. ' ~t~| ~b~Nom : ~w~' .. name .. " ~t~| ~b~Joueurs : ~w~" .. #players .. " / 64")
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(100)
		SetData()
	end
end)

Citizen.CreateThread(function()
    AddTextEntry("PM_PANE_LEAVE", "~b~Quitter ~w~NEO")
end)

Citizen.CreateThread(function()
    AddTextEntry("PM_PANE_QUIT", "~b~Quitter ~w~FiveM")
end)

-- Discord rich presents
local appid = '710577521355259985'
local asset = 'neo'

function SetRP()
    local name = GetPlayerName(PlayerId())
    local id = GetPlayerServerId(PlayerId())

    SetRichPresence(name .. ' Joue sur NEO')
    SetDiscordAppId(appid)
    SetDiscordRichPresenceAsset('large')
end

Citizen.CreateThread(function()
    SetRP()
end)