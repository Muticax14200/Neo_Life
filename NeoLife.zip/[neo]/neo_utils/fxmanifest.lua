fx_version 'bodacious'
games { 'rdr3', 'gta5' }

client_script '3dme_cl.lua'
client_script 'pause.lua'
client_script 'cl_utils.lua'
client_script 'cl_status.lua'
client_script 'cl_eup.lua'


server_script '@mysql-async/lib/MySQL.lua'
server_script '3dme_sv.lua'