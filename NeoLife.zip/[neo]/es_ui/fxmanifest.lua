fx_version 'adamant'

game 'gta5'

description 'es_ui by Kanersps.'

ui_page 'ui.html'

client_script 'client.lua'

-- NUI Files
files {
	'ui.html',
	'pdown.ttf'
}
