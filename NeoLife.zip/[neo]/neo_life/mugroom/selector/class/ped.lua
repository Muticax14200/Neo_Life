local Cam = Camera.New()
local SelectedEntity = 1
local PedList = {}
local ScaleformBoard = {}

onSelectorTick = {
    Scaleform = false,
    Controls = false,
    RageUI = false,
}

---LineupDictionary
--- Permet de detecté les animation a play sur une entité selon sons ped freemode Method N°1
---@param v table
---@param k table
local function LineupDictionary(v, k)
    if (v.Model == "mp_f_freemode_01") then
        ---mp_f_freemode_01
        if (k == 1) then
            return "mp_character_creation@lineup@female_b"
        elseif (k == 2) then
            return "mp_character_creation@lineup@female_a"
        end
    elseif (v.Model == "mp_m_freemode_01") then
        ---mp_m_freemode_01
        if (k == 1) then
            return "mp_character_creation@lineup@male_b"
        elseif (k == 2) then
            return "mp_character_creation@lineup@male_a"
        end
    end
end

---LineupDictionary_02
--- Permet de detecté les animation a play sur une entité selon sons ped freemode Method N°1
---@param CurrentEntity number
---@param Entity number
local function LineupDictionary_02(CurrentEntity, Entity)
    if (GetEntityModel(Entity) == GetHashKey('mp_f_freemode_01')) then
        if (CurrentEntity == 1) then
            return "mp_character_creation@lineup@female_b"
        else
            return "mp_character_creation@lineup@female_a" -- TODO Surement besoin d'un fix selon le personnage
        end
    elseif (GetEntityModel(Entity) == GetHashKey('mp_m_freemode_01')) then
        if (CurrentEntity == 1) then
            return "mp_character_creation@lineup@male_a"
        else
            return "mp_character_creation@lineup@male_b"
        end
    end
end

function PedAdd(Model, UUID, Face, Outfit, Tattoo, RoleplayTable)
    local _Add = {
        Entity = nil,
        UUID = UUID,
        Model = Model,
        Face = Face,
        Outfit = Outfit,
        Tattoo = Tattoo,
        Roleplay = RoleplayTable
    }
    table.insert(PedList, _Add)
end

function CreatePeds()
    TriggerEvent('es:setMoneyDisplay', 0.0)
    for key, value in pairs(PedList) do
        value.Entity = CreatePed(25, value.Model, 409.02, -1000.8, -99.859, -15.0, 0, 0)
        ClearPedTasksImmediately(value.Entity)
        SetPedDefaultComponentVariation(value.Entity)
        TaskSetBlockingOfNonTemporaryEvents(value.Entity, true)
        StopPedSpeaking(value.Entity, 1)
        DisablePedPainAudio(value.Entity, 1)
        FreezePedCameraRotation(value.Entity)

        --- CPU TICK SO HIGH
        UpdateEntityFace(value.Entity, value.Face)
        UpdateEntityOutfit(value.Entity, value.Outfit)
        UpdateEntityTattoo(value.Entity, value.Tattoo)
    end
    Citizen.Wait(100.0)
    for key, value in pairs(PedList) do
        local _, sequence = OpenSequenceTask(0)
        --(LineupDictionary(value, key))
        TaskPlayAnimAdvanced(0, LineupDictionary(value, key), "Intro", 409.02, -1000.8, -98.859, 0.0, 0.0, 0.0, 8.0, -8.0, -1, 4608, 0, 2, 0)
        TaskPlayAnim(0, LineupDictionary(value, key), "Loop", 8.0, -4.0, -1, 513, 0, 0, 0, 0)
        CloseSequenceTask(sequence)
        TaskPerformSequence(value.Entity, sequence)

        attachBoardToPed(value.Entity, value.Roleplay.FirstName, value.Roleplay.LastName, Jobs[value.Roleplay.Jobs].label, value.Roleplay.BankAmount, key ~= 1)
    end
end

function attachBoardToPed(Entity, FirstName, LastName, Jobs, BankAmount, Index)
    if BankAmount== nil then
        BankAmount = 0
    end
    local prop_id_board = GetHashKey("prop_police_id_board")
    local pedPos, overlayModel = GetEntityCoords(Entity), not Index and GetHashKey("prop_police_id_text") or GetHashKey("prop_police_id_text_02")
    local board = CreateObject(prop_id_board, pedPos, false, true, false)
    local overlay = CreateObject(overlayModel, pedPos, false, true, false)
    AttachEntityToEntity(overlay, board, -1, 4103, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
    SetModelAsNoLongerNeeded(prop_id_board)
    SetModelAsNoLongerNeeded(overlayModel)
    AttachEntityToEntity(board, Entity, GetPedBoneIndex(Entity, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0, 0, 0, 2, 1)
    local handleName = Index and "ID_Text_02" or "ID_Text"
    table.insert(ScaleformBoard, {
        handleName = handleName,
        overlayModel = overlayModel,
        obj = { board, overlay },
        handle = CreateNamedRenderTargetForModel(handleName, overlayModel),
        scaleform = createScaleform(Index and "MUGSHOT_BOARD_02" or "mugshot_board_01", {
            { name = "SET_BOARD", param = {
                FirstName .. " " .. LastName,
                BankAmount .. " $",
                "LOS SANTOS POLICE DEPT",
                Jobs
            } }
        })
    })
    onSelectorTick.Scaleform = true
end

---TaskHoldBoard
---@param Entity number
function TaskHoldBoard(Entity, bl)
    local _, sequence = OpenSequenceTask(0)
    TaskPlayAnim(0, LineupDictionary_02(bl, Entity), "high_to_low", 8.0, -8.0, -1, 512, 0, 0, 0, 0)
    TaskPlayAnim(0, LineupDictionary_02(bl, Entity), "Loop", 8.0, -8.0, -1, 513, 0, 0, 0, 0)
    CloseSequenceTask(sequence)
    TaskPerformSequence(Entity, sequence)
    ClearSequenceTask(sequence)
end

---TaskRaiseBoard
---@param Entity number
local function TaskRaiseBoard(Entity, bl)
    local _, sequence = OpenSequenceTask(0)
    --(LineupDictionary_02(bl, Entity))
    TaskPlayAnim(0, LineupDictionary_02(bl, Entity), "low_to_high", 8.0, -8.0, -1, 512, 0, 0, 0, 0)
    TaskPlayAnim(0, LineupDictionary_02(bl, Entity), "Loop_raised", 8.0, -8.0, -1, 513, 0, 0, 0, 0)
    CloseSequenceTask(sequence)
    TaskPerformSequence(Entity, sequence)
    ClearSequenceTask(sequence)
end

local function FocusAnotherPed()
    SelectedEntity = SelectedEntity == 1 and 2 or 1
    local Entity, bl = PedList[SelectedEntity].Entity, SelectedEntity == 2
    Camera:Stage_03(Cam.cam_466, not bl)
    Camera:Stage_03_A(Cam.cam_465, Cam.cam_466, not bl)
    TaskRaiseBoard(Entity, bl)
    TaskHoldBoard(PedList[SelectedEntity == 1 and 2 or 1].Entity, bl)
    return SelectedEntity
end

function ReactToLight()
    for k, v in pairs(PedList) do
        local _, sequence = OpenSequenceTask(0)
        TaskPlayAnim(0, LineupDictionary(v, k), "react_light", 8.0, -4.0, -1, 513, 0, 0, 0, 0)
        CloseSequenceTask(sequence)
        TaskPerformSequence(v.Entity, sequence)
    end
    Citizen.Wait(5000)
    --TaskRaiseBoard(PedList[1].Entity)

    onSelectorTick.RageUI = true
    OpenMenuSelector()

    if (#PedList > 1) then
        local _, sequence = OpenSequenceTask(0)
        TaskPlayAnim(0, LineupDictionary_02(2, PedList[2].Entity), "Loop", 8.0, -4.0, -1, 513, 0, 0, 0, 0)
        CloseSequenceTask(sequence)
        TaskPerformSequence(PedList[2].Entity, sequence)
    end
end

function ExitPedFormRoom()
    local Entity = PedList[SelectedEntity].Entity

    local _, sequence = OpenSequenceTask(0)
    if(SelectedEntity == 1)then
        TaskPlayAnim(0, LineupDictionary_02(2, Entity), "outro", 8.0, -8.0, -1, 512, 0, 0, 0, 0)
        TaskPlayAnim(0, LineupDictionary_02(2, Entity), "outro_loop", 8.0, -8.0, -1, 513, 0, 0, 0, 0)
    else

        TaskPlayAnim(0, LineupDictionary_02(1, Entity), "outro", 8.0, -8.0, -1, 512, 0, 0, 0, 0)
        TaskPlayAnim(0, LineupDictionary_02(1, Entity), "outro_loop", 8.0, -8.0, -1, 513, 0, 0, 0, 0)
    end
    CloseSequenceTask(sequence)
    TaskPerformSequence(PedList[SelectedEntity].Entity, sequence)
    ClearSequenceTask(sequence)
end

function StartScenario()
    Cam.cam_466 = CreateCam("DEFAULT_SCRIPTED_CAMERA", false)
    Cam.cam_465 = CreateCam("DEFAULT_SCRIPTED_CAMERA", false)
    Camera:Stage_01(Cam.cam_465)

    DoScreenFadeIn(500)
    RemoveLoadingPrompt()

    CreatePeds()
    Camera:func_1673(Cam.cam_465, 7.2, 1.0, 0.5, 1.0)
    ShakeCam(Cam.cam_465, "HAND_SHAKE", 1.0)
    RenderScriptCams(1, 0, 3000, 1, 0)
    Citizen.Wait(5000)
    Camera:Stage_02(Cam.cam_466)
    Camera:Stage_02_A(Cam.cam_465, Cam.cam_466)
    Citizen.Wait(3500)
    NetworkOverrideClockTime(0, 0, 0)
    PlaySoundFrontend(-1, "Lights_On", "GTAO_MUGSHOT_ROOM_SOUNDS", true)
    ReactToLight()
end

function OnSelectorUpdateMenuContent()
    return PedList[SelectedEntity]
end

function OnRenderSelectorScaleform()
    HideHudAndRadarThisFrame()
    for k, v in pairs(ScaleformBoard) do
        SetTextRenderId(ScaleformBoard[k].handle)
        SetScriptGfxDrawOrder(4)
        Citizen.InvokeNative(0xC6372ECD45D73BCD, 1)
        DrawScaleformMovie(ScaleformBoard[k].scaleform, 0.405, 0.37, 0.81, 0.74, 255, 255, 255, 255, 0)
        Citizen.InvokeNative(0xC6372ECD45D73BCD, 0)
        SetTextRenderId(GetDefaultScriptRendertargetRenderId())
    end
end

function OnLeftPressed()
    if (#PedList > 1) then
        if IsCamInterpolating(Cam.cam_456) or IsCamInterpolating(Cam.cam_466) then
            return
        else
            PlaySoundFrontend(-1, "NAV_LEFT_RIGHT", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
        end
        FocusAnotherPed()
    else
        PlaySoundFrontend(-1, "ERROR", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    end
end

function OnRightPressed()
    if (#PedList > 1) then
        if IsCamInterpolating(Cam.cam_456) or IsCamInterpolating(Cam.cam_466) then
            return
        else
            PlaySoundFrontend(-1, "NAV_LEFT_RIGHT", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
        end
        FocusAnotherPed()
    else
        PlaySoundFrontend(-1, "ERROR", "HUD_FRONTEND_DEFAULT_SOUNDSET", true)
    end
end

function GetPedList()
    return PedList
end

function RequestAssets()
    local animsToLoad = {
        [1] = "mp_character_creation@lineup@male_a",
        [2] = "mp_character_creation@lineup@male_b",
        [3] = "mp_character_creation@lineup@female_a",
        [4] = "mp_character_creation@lineup@female_b",
        [5] = "mp_character_creation@customise@female_a",
        [6] = "mp_character_creation@customise@male_a",
        [7] = "mp_character_creation@customise@female_a"
    }
    for i = 1, #animsToLoad, 1 do
        Streaming:AnimationDictionary(animsToLoad[i])
    end
    RequestModel("prop_police_id_board")
    RequestModel("prop_police_id_text")
    RequestModel("prop_police_id_text_02")
    RequestScriptAudioBank("DLC_GTAO/MUGSHOT_ROOM", false, -1)
    RequestScriptAudioBank("Mugshot_Character_Creator", false, -1)
end

function DeleteAssets()
    local animsToUnLoad = {
        [1] = "mp_character_creation@lineup@male_a",
        [2] = "mp_character_creation@lineup@male_b",
        [3] = "mp_character_creation@lineup@female_a",
        [4] = "mp_character_creation@lineup@female_b",
        [5] = "mp_character_creation@customise@female_a",
        [6] = "mp_character_creation@customise@male_a",
        [7] = "mp_character_creation@customise@female_a"
    }
    ReleaseScriptAudioBank("DLC_GTAO/MUGSHOT_ROOM")
    ReleaseScriptAudioBank("Mugshot_Character_Creator")
    SetModelAsNoLongerNeeded("prop_police_id_board")
    SetModelAsNoLongerNeeded("prop_police_id_text")
    SetModelAsNoLongerNeeded("prop_police_id_text_02")
    for _, v in pairs(animsToUnLoad) do
        RemoveAnimDict(v)
    end
end

local function onExited()
    DoScreenFadeIn(2500)
    Citizen.Wait(500)

    onSelectorTick.Scaleform = false
    onSelectorTick.RageUI = false
    onSelectorTick.Controls = false

    local interiorID = GetInteriorAtCoordsWithType(vector3(399.9, -998.7, -100.0), "v_mugshot")
    DeleteAssets()
    UnpinInterior(interiorID)
    Camera:DeleteAll()
    LocalPlayer().isBusy = false
    LocalPlayer().isCinematic = false
    TriggerEvent('es:setMoneyDisplay', 1.0)
    local ped = LocalPlayer().Ped
    SetEntityVisible(ped, 1, 1)
    SetEntityInvincible(ped, 0)
    FreezeEntityPosition(ped, 0)
    RMenu:Delete('mugshot', 'selector')
end

RegisterNetEvent('selector:onExited')
AddEventHandler('selector:onExited', function()
    onExited()
end)