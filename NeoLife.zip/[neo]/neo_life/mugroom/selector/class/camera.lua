Camera = {}

function Camera.New()
    local _Camera = {
        cam_466 = CreateCam("DEFAULT_SCRIPTED_CAMERA", false),
        cam_456 = CreateCam("DEFAULT_SCRIPTED_CAMERA", false),
    }
    return setmetatable(_Camera, Camera)
end

function Camera:func_1673(camera, arg1, arg2, arg3, arg4)
    Citizen.InvokeNative(0xF55E4046F6F831DC, camera, arg1)
    Citizen.InvokeNative(0xE111A7C0D200CBC5, camera, arg2)
    SetCamDofFnumberOfLens(camera, arg3)
    SetCamDofMaxNearInFocusDistanceBlendLevel(camera, arg4)
end

function Camera:Stage_01(Camera)
    SetCamCoord(Camera, 416.4084, -998.3806, -99.24789)
    SetCamRot(Camera, 0.878834, -0.022102, 90.0173, 2)
    SetCamFov(Camera, 36.97171)
    SetCamActive(Camera, true)
end

function Camera:Stage_02(Camera)
    SetCamCoord(Camera, 415.1931, -998.5322, -98.98548)
    SetCamRot(Camera, 0.865862, -0.01934, 94.4191, 2)
    SetCamFov(Camera, 25.2015)
    self:func_1673(Camera, 6.6, 1.0, 0.5, 1.0)
    SetCamActive(Camera, true)
    ShakeCam(Camera, "HAND_SHAKE", 0.1)
end

function Camera:Stage_02_A(f_465, f_466)
    local gameplayPos = GetGameplayCamCoords()
    local gameplayRot = GetCamRot(f_465, 2)
    local unkVar2 = Citizen.InvokeNative(0x80ec114669daeff4)

    SetCamCoord(f_465, gameplayPos)
    SetCamRot(f_465, gameplayRot, 2)
    SetCamFov(f_465, unkVar2)
    self:func_1673(f_465, 7.2, 1.0, 0.5, 1.0)
    ShakeCam(f_465, "HAND_SHAKE", 0.1)
    SetCamActive(f_465, true)
    SetCamActiveWithInterp(f_466, f_465, 10000, 1, 1)
end

function Camera:Stage_03(f_466, Index)
    if Index then
        SetCamCoord(f_466, 414.8992, -998.4008, -98.98119)
        SetCamRot(f_466, 0.597248, -0.01934, 103.2173, 2)
        SetCamFov(f_466, 25.2015)
    else
        SetCamCoord(f_466, 415.0216, -998.0448, -98.98355)
        SetCamRot(f_466, 0.865862, -0.01934, 91.04581, 2)
        SetCamFov(f_466, 25.2015)
    end
    self:func_1673(f_466, 5.8, 1.0, 0.5, 1.0)
    SetCamActive(f_466, 1)
    ShakeCam(f_466, "HAND_SHAKE", 0.1)
end

function Camera:Stage_03_A(f_465, f_466)
    local gameplayPos = GetCamCoord(f_466)
    local gameplayRot = GetCamRot(f_466)
    local unkVar2 = GetCamFov(f_466)

    SetCamCoord(f_465, gameplayPos)
    SetCamRot(f_465, gameplayRot, 2)
    SetCamFov(f_465, unkVar2)
    self:func_1673(f_465, 5.8, 1.0, 0.5, 1.0)
    ShakeCam(f_465, "HAND_SHAKE", 0.1)
    SetCamActive(f_465, true)

    SetCamActiveWithInterp(f_466, f_465, 1000, 3, 3)
end

function Camera:DeleteAll()
    DestroyCam(self.cam_465, 0)
    DestroyCam(self.cam_466, 0)
    RenderScriptCams(0, 0, 0, 1, 1)
    self.cam_465, self.cam_466 = nil, nil
end