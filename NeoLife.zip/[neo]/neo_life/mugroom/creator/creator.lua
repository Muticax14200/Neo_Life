RegisterNetEvent('mugroom:Finish')

Creator = {}

local _Cam

function RegenCreatorCam()
    _Cam = CamCreatorInit();
end

function GetCreatorCam()
    return _Cam
end

function Creator.LoadContent()
    SetOverrideWeather("EXTRASUNNY")
    SetWeatherTypePersist("EXTRASUNNY")
    NetworkOverrideClockTime(16, 0, 0)

    RegenCreatorCam()
    CreatorRequestAssets()
    Citizen.Wait(1000)
    DoScreenFadeIn(500)
    while not IsScreenFadedIn() do
        Citizen.Wait(0)
    end
    RemoveLoadingPrompt()

    Stage_01(_Cam)
    Stage_01_A(_Cam)
    RenderScriptCams(true, false, 3000, 1, 0, 0)
    WalkToRoom()
    Citizen.Wait(0000)

    OpenCreatorMenu()
    onCreatorTick.Tick = true
end

AddEventHandler('mugroom:Finish', function(SpawnLocation)
    Citizen.Wait(500)

    --(dump(SpawnLocation))
    if (SpawnLocation.index == 1) then
        LOSSANTOS()
    elseif (SpawnLocation.index == 2) then
        DESERT()
    end

    TriggerServerCallback('spawned:requestData', function(ActiveCharacter, ActionID, Table, Identity, Jobs, Users)
        --(json.encode(Users))
        TriggerEvent("es:activateMoney",Users[1].money)
        TriggerEvent("es:activateBlackMoney",Users[1].black_money)
        player_group = Users[1].group
        PlySkin = Table[1].face
        Inventory:Load()
        PlyUuid = Users[1].uuid
        Job:Set(Jobs[1].name,Jobs[1].rank)
        XNL_SetInitialXPLevels(tonumber(Users[1].xp))
        Orga:Set(Jobs[1].orga,Jobs[1].orga_rank)
        StartEverything()
    end)
end)

function UpdateCreatorTick(type, value)
    onCreatorTick[type] = value
end

local isTurnedLeft = false
local isTurnedRight = false

AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then
        return
    end
    NetworkClearClockTimeOverride()
    CreatorDeleteAssets()
end)

