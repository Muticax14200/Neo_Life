Jobs = {

    -- garage type 2 = tout ceux qui ont le job voient les véhicule que n'importe quel joueur du job met
    -- 1 = self service
    -- 0 = classique
    chomeur = {
        label = "Citoyen",
        grade = {
            {
                label = "",
                salary = 20
            },
        }
    },

    fermier = {
        label = "Fermier",
        label2 = "Fermier",
        FreeAccess = true,
        grade = {
            {
                label = "Fermier",
                salary = 40,
                name = "worker"
            },
            {
                label = "Gérant",
                salary = 80,
                name = "gerant"
            },
            {
                label = "Patron",
                salary = 120,
                name = "boss"
            }
        },
        garage = {
            Name = "Garage vigneron",
            Pos =  {x = 2015.23,  y = 4979.07,  z =41.88}, 
            Properties = {
                type = 1,
                Limit = 15,
                vehicles = {
                    {name="tractor2",label="Voiture de service",job=true,tuning = {
                        modXenon = true
                    }},

                },
                spawnpos = {x = 2015.23,  y = 4979.07,  z =41.88,h=339.66}, 

            },
            Blipdata = {
                Pos = {x = 2015.23,  y = 4979.07,  z =41.88}, 
                Blipcolor  =7,
                Blipname = "Garage"
            }
        },
        requiredService = false,
        work = {

            recolte = {
                type = "recolte",
                workSize = 10.0,
                Pos = {x=2201.97,y=5179.28,z=58.35},
                giveitem = "blez",
                blipcolor =7,
                blipname = "Récolte du blé",
                add = "~p~+ 1 Blé",
                anim = {
      
                    lib = "anim@mp_snowball",
                    anim = "pickup_snowball"
            
                },
            },
            traitement = {
                type = "traitement",
                workSize = 10.45,
                blipcolor =7,
                blipname = "Traitement du blé",
                Pos =  {x=2309.5,y=4885.85,z=41.81},
                required = "blez",
                giveitem = "farine",
                add = "~p~+ 1  Farine"
            },
            traitement2 = {
                type = "traitement",
                workSize = 10.45,
                blipcolor =7,
                blipname = "Traitement de la farine",
                Pos =  {x=2680.62,y=3508.35,z=53.3},
                required = "farine",
                giveitem = "pain",
                add = "~p~+ 1  Pain"
            },
            vente = {
                type = "vente",
                blipcolor =7,
                workSize = 10.45,
                blipname = "Vente",
                Pos = {x=83.14,y=-1551.22,z=29.6},
                required = "pain",
                price = math.random( 28,68 ),
                add = "~p~- 1 Pain"
            },
        }
    },
    vigneron = {
        label = "Vigneron",
        label2 = "Vigneron",
        FreeAccess = true,
        grade = {
            {
                label = "CDD",
                salary = 50,
                name = "cdd"
            },
            {
                label = "CDI",
                salary = 100,
                name = "cdi"
            },
            {
                label = "Patron",
                salary = 150,
                name = "boss"
            }
        },
        Menu = {
            menu = {
                title = "Vigneron",
                subtitle = "Actions disponibles",
                name = "vigneron_menuperso"
            },
            buttons = {
                {label="Facturation",onSelected=function() CreateFacture("vigneron") end,ActiveFct=function() HoverPlayer() end},
            },
        },
        garage = {
            Name = "Garage vigneron",
            Pos =  {x = -1887.76,  y = 2045.01,  z =139.86}, 
            Properties = {
                type = 1,
                Limit = 15,
                vehicles = {
                    {name="bison",label="Voiture de service",job=true,tuning = {
                        modXenon = true
                    }},

                },
                spawnpos = {x = -1895.71,  y = 2034.61,  z =141.86,h=339.66}, 

            },
            Blipdata = {
                Pos = {x = -1887.76,  y = 2045.01,  z =139.86}, 
                Blipcolor  =7,
                Blipname = "Garage"
            }
        },
        requiredService = false,
    
        work = {

            recolte = {
                type = "recolte",
                workSize = 10.0,
                Pos = {x=-1812.54,y=2206.83,z=92.37},
                giveitem = "raisin",
                blipcolor =7,
                blipname = "Récolte",
                add = "~p~+ 1 Raisin",
                anim = {
      
                    lib = "anim@mp_snowball",
                    anim = "pickup_snowball"
            
                },
            },
            traitement2 = {
                type = "traitement",
                workSize = 10.45,
                blipcolor =7,
                blipname = "Traitement raisin",
                Pos = {x=-52.83,y=1903.4,z=195.36},
                required = "raisin",
                giveitem = "jus_raisin",
                add = "~p~+ 1  Jus de raisin"
            },
            
            traitement = {
                type = "traitement",
                workSize = 10.45,
                blipcolor =7,
                blipname = "Traitement jus de raisin",
                Pos = {x=-1929.02,y=1779.09,z=173.07},
                required = "jus_raisin",
                giveitem = "bouteille_vin",
                add = "~p~+ 1  Bouteille de vin"
            },
            vente = {
                type = "vente",
                blipcolor =7,
                workSize = 10.45,
                blipname = "Vente",
                Pos = {x=51.59,y=6486.16,z=31.36},
                required = "bouteille_vin",
                price = math.random( 28,98 ),
                add = "~p~- 1 Bouteille de vin"
            },
        },
        Storage = {
            {
                Pos = {x=-1923.54,y=2054.35,z=140.83},
                Limit = 500,
                Name = "coffre_vigneron"
            },
        },
    },

    bucheron = {
        label = "Bûcheron",
        label2 = "Bucheron",
        FreeAccess = true,
        grade = {
            {
                label = "CDD",
                salary = 55,
                name = "cdd"
            },
            {
                label = "CDI",
                salary = 75,
                name = "cdi"
            },
            {
                label = "Patron",
                salary = 175,
                name = "boss"
            }
        },
        garage = {
            Name = "Garage Bûcheron",
            Pos =  {x = -568.01,  y = 5253.35,  z =70.49}, 
            Properties = {
                type = 1,
                Limit = 15,
                vehicles = {
                    {name="bison3",label="Voiture de service",job=true,tuning = {modXenon = true}},
                },
                spawnpos = {x = -580.74,  y = 5240.01,  z =70.47, h=131.49}, 

            },
            Blipdata = {
                Pos = {x = -568.01,  y = 5253.35,  z =70.49}, 
                Blipcolor  =7,
                Blipname = "Garage"
            }
        },
        requiredService = false,
    
        work = {
            recolte = {
                type = "recolte",
                workSize = 10.0,
                Pos = {x=-1585.65,y=4649.73,z=47.12},
                giveitem = "bois",
                blipcolor =7,
                blipname = "Récolte de bois",
                add = "~p~+ 1 bois",
                anim = {
      
                    lib = "anim@mp_snowball",
                    anim = "pickup_snowball"
            
                },
            },
            traitement2 = {
                type = "traitement",
                workSize = 10.45,
                blipcolor =7,
                blipname = "Scirie",
                Pos = {x=-560.8,y=5282.72,z=73.05},
                required = "bois",
                giveitem = "planche",
                add = "~p~+ 1  Planche"
            },
            vente = {
                type = "vente",
                blipcolor =7,
                workSize = 10.45,
                blipname = "Vente de planche",
                Pos = {x=51.59,y=6486.16,z=31.36},
                required = "planche",
                price = math.random( 12,24 ),
                add = "~p~- 1 Planche"
            },
        }
    },

    raffinerie = {
        label = "Rafinerie",
        label2 = "Rafinerie",
        FreeAccess = true,
        grade = {
            {
                label = "Raffineur",
                salary = 40,
                name = "cdd"
            },
            {
                label = "Responsable de prod",
                salary = 80,
                name = "cdi"
            },
            {
                label = "Patron",
                salary = 130,
                name = "boss"
            }
        },
        Menu = {
            menu = {
                title = "Raffinerie",
                subtitle = "Actions disponibles",
                name = "Raffinerie_menuperso"
            },

            buttons = {
                {label="Facture",onSelected=function() CreateFacture("raffinerie") end,ActiveFct=function() HoverPlayer() end},
            },
        },
        requiredService = false,
    
        work = {

            recolte = {
                type = "recolte",
                workSize = 10.0,
                Pos = {x=1343.01,y=-2113.07,z=54.85},
                giveitem = "petrol",
                blipcolor =7,
                blipname = "Récolte",
                add = "~p~+ 1 Pétrole",
                anim = {
      
                    lib = "anim@mp_snowball",
                    anim = "pickup_snowball"
            
                },
            },
            traitement2 = {
                type = "traitement",
                workSize = 10.45,
                blipcolor =7,
                blipname = "Traitement pétrole",
                Pos = {x=270.72,y=-3056.22,z=5.83},
                required = "petrol",
                giveitem = "petrol_melanged",
                add = "~p~+ 1  Mélange pétrole"
            },
            
            traitement = {
                type = "traitement",
                workSize = 10.45,
                blipcolor =7,
                blipname = "Traitement mélange pétrole",
                Pos = {x=2760.85,y=1486.87,z=30.79},
                required = "petrol_melanged",
                giveitem = "petrol_rafined",
                add = "~p~+ 1  Pétrole raffiné"
            },
            vente = {
                type = "vente",
                blipcolor =7,
                workSize = 10.45,
                blipname = "Vente",
                Pos = {x=51.59,y=6486.16,z=31.36},
                required = "petrol_rafined",
                price = math.random( 16,38 ),
                add = "~p~- 1 Pétrole raffiné"
            },
        }
    },

    police = {  
        label = "LSPD",
        label2 = "LSPD",
        grade = {
            {
                label = "Cadet",
                salary = 75,
                name = "cadet"
            },
            {
                label = "Officier I",
                salary = 125,
                name = "officierI"
            },
            
            {
                label = "Officier II",
                salary = 165,
                name = "officierII"
            },
            {
                label = "Officier III",
                salary = 225,
                name = "officierIII"
            },
            {
                label = "Sergent",
                salary = 35,
                name = "sergent"
            },
            {
                label = "Sergent-Chef",
                salary = 40,
                name = "sergent-Chef"
            },
            {
                label = "Lieutenant",
                salary = 45,
                name = "drh"
            },
            {
                label = "Capitaine",
                salary = 50,
                name = "BD"
            },
            {
                label = "Commandant",
                salary = 60,
                name = "boss"
            }
        },
        garage = {
            Name = "Garage police",
            Pos =  {x = 438.53,  y = -1021.1,  z = 27.63, h=87.59},
            Properties = {
                type = 1,
                Limit = 50,
                vehicles = {
                    {name="police",label="Police 1",job=true,tuning = {
                       modXenon = true
                    }}, 
                    {name="police2",label="Police 2",job=true,tuning = {
                       modXenon = true
                    }},
                    {name="police3",label="Police 3",job=true,tuning = {
                        modXenon = true
                     }},
                    {name="police4",label="Police 4",job=true,tuning = {
                       modXenon = true 
                    }},
                    {name="police5",label="Police 5",job=true,tuning = {
                       modXenon = true  
                    }},
                    {name="police6",label="Police 6",job=true,tuning = {
                        modXenon = true  
                    }},
                    {name="police7",label="Police 7",job=true,tuning = {
                        modXenon = true  
                    }},
                    {name="police8",label="Police 8",job=true,tuning = {
                        modXenon = true  
                    }}, 
                    {name="police9",label="Police 9",job=true,tuning = {
                        modXenon = true  
                    }}, 
                    {name="policet",label="Police T",job=true,tuning = {
                        modXenon = true  
                    }}, 
                    {name="riot",label="Riot",job=true,tuning = {
                        modXenon = true  
                    }}, 
                },
                spawnpos = {x = 438.53,  y = -1021.1,  z = 27.63, h=87.59},

         },
          Blipdata = {
            Pos = {x = 438.53,  y = -1021.1,  z = 27.63, h=87.59},
            Blipcolor  =7,
            Blipname = "Garage"
          }
       },
        Menu = {
            menu = {
                title = "Police",
                subtitle = "Actions disponibles",
                name = "police_menuperso"
            },
            submenus = {
                ["Actions citoyen"] = {
                    submenu ="police_menuperso",
                    title = "Actions citoyen",
                    menus = {
                        buttons = {
                            {label="Menotter",onSelected=function() Police.HandcuffPly() end,ActiveFct= function() HoverPlayer() end},
                            {label="Démenotter",onSelected=function() Police.CutMenottes() end,ActiveFct= function() HoverPlayer() end},
                            {label="Retrait points permis",onSelected=function() Police.RetraitPermis() end},
                        },
                        submenus = {}
                    }

                },
                ["Actions véhicule"] = {
                    submenu ="police_menuperso",
                    title = "Actions véhicule",
                    menus = {
                        buttons = {
                            {label="Inspecter la plaque",onSelected=function() Police.PlateCheck() end,ActiveFct= function() Mecano.ShowMarker() end},
                            {label="Crocheter",onSelected=function() Police.Crocheter() end,ActiveFct= function() Mecano.ShowMarker() end},
                            {label="Immobiliser",onSelected=function() Police.Immobiliser() end,ActiveFct= function() Mecano.ShowMarker() end},
                            
                        },
                        submenus = {}
                    }

                },
            },
            buttons = {
                {label="Amendes",onSelected=function() CreateFacture("police") end,ActiveFct=function() HoverPlayer() end},
                {label="Appelez des renforts",onSelected=function()             local plyCoords = GetEntityCoords(GetPlayerPed(-1))
            local x,y,z = table.unpack(plyCoords)
            TriggerServerEvent("call:makeCall","police",{x=x,y=y,z=z},"J'ai besoin de renfort!") end,ActiveFct=function() end}
            },
        },
        Storage = {
            {
                Pos = {x=452.4,y=-979.52,z=29.69},
                Limit = 500,
                Name = "coffre"
            },
        },
    },

    banker = {
        label = "Banquier",
        grade = {
            {
                label = "Employé",
                salary = 30,
                name = "employe",
                show = true
            },
            {
                label = "Trésorier",
                salary = 35,
                name = "tresorier",
                show = true
            },
            {
                label = "DRH",
                salary = 40,
                name = "drh",
                show = true
            },
            {
                label = "PDG",
                salary = 60,
                name = "pdg",
                show = true                
            }
        },
        Menu = {
            menu = {
                title = "Banquier",
                subtitle = "Actions disponibles",
                name = "Banquier_menuperso"
            },

            buttons = {
                {label="Facture",onSelected=function() CreateFacture("LS-PBANK") end,ActiveFct=function() HoverPlayer() end},
            },
        },
        Extrapos = {
            Banker = { -- fourrière
                Pos = {
                    {x=249.93,y=230.25,z=106.29}
                },
                Enter = function()
                    EnterBankZone()  
                end,
                Exit = function()
                    ExitBankZone()  
                end,
                zonesize = 1.5,
                Blips = {
                    sprite = 500,
                    color = 69,
                    name = "Gestion comptes",
                },
                Marker = {
                    type = 1,
                    scale = {x=1.5,y=1.5,z=0.2},
                    color = {r=255,g=255,b=255,a=120},
                    Up = false,
                    Cam = false,
                    Rotate = false,
                    visible = true
                }
            },
        },
    },

    lsms = {    
        label = "LSMS",
        grade = {
            {
                label = "Infirmier",
                salary = 30,
                name = "infirmier",
                show = true            
            },
            {
                label = "Médecin",
                salary = 40,
                name = "medecin",
                show = true
            },
            {
                label = "Médecin-chef",
                salary = 50,
                name = "medecinchef",
                show = true
            }, 
            {
                label = "Directeur adjoint",
                salary = 60,
                name = "drh",
                show = true                
            },
            {
                label = "Directeur",
                salary = 70,
                name = "boss",
                show = true               
            },
        },
        garage = {
            Name = "Garage ambulance",
            Pos =  {x=323.48,y=-548.58,z=27.79}, 
            Properties = {
                type = 1,-- = garage self service 
                Limit = 50,
                vehicles = {
                    {name="ambulance",label="Voiture de service",job=true,tuning = {
                        modXenon = true
                    }},     
                },
                spawnpos =  {x=330.98,y=-548.4,z=27.79,h=267.44}, 

            },
            Blipdata = {
                Pos =  {x=323.48,y=-548.58,z=27.79}, 
                Blipcolor  =7,
                Blipname = "Garage LSMS"
            }
        },
        Storage = {
            {
                Pos = {x=335.77,y=-584.8,z=27.79},
                Limit = 500,
                Name = "coffre_lsms"
            },
        },
        Menu = {
            menu = {
                title = "Ambulance",
                subtitle = "Actions disponibles",
                name = "ambulance_menuperso"
            },
            buttons = {
                {label="Facturation",onSelected=function() CreateFacture("lsms") end,ActiveFct=function() HoverPlayer() end},
                {label="Réanimation",onSelected=function() Ambulance.Revive() end,ActiveFct=function() HoverPlayer() end},
                {label="Soin",onSelected=function() Ambulance.Heal() end,ActiveFct=function() HoverPlayer() end},

            },
        },
    },

    mecano = {     
        label = "Mécanicien",
        label2 = "Benny's Custom",
        grade = {
            {
                label = "Employé",
                salary = 100,
                name = "employe",
                show = true               
            },
            {
                label = "Trésorier",
                salary = 200,
                name = "tresorier",
                show = true              
            },
            {
                label = "DRH",
                salary = 300,
                name = "drh",
                show = true
            },
            {
                label = "PDG",
                salary = 400,
                name = "boss",
                show = true           
            }
        },
        Menu = {
            menu = {
                title = "Mécano",
                subtitle = "Actions disponibles",
                name = "mecano_menuperso"
            },
            submenus = {
                ["Actions véhicule"] = {
                    submenu ="mecano_menuperso",
                    title = "Actions véhicule",
                    menus = {
                        buttons = {
                            {label="Inspecter l'état du véhicule",onSelected=function() Mecano.CheckVehicle() end,ActiveFct= function() Mecano.ShowMarker() end},
                            {label="Ouvrir le capot",onSelected=function() Mecano.OpenTrunk() end,ActiveFct= function() Mecano.ShowMarker() end},
                            {label="Réparer le véhicule",onSelected=function() Mecano.Repair() end,ActiveFct= function() Mecano.ShowMarker() end},
                            {label="Nettoyer le véhicule",onSelected=function() Mecano.CleanVehicule() end,ActiveFct= function() Mecano.ShowMarker() end},
                        },
                        submenus = {}
                    }

                },

            },
            buttons = {
                {label="Facturation",onSelected=function() CreateFacture("mecano") end,ActiveFct=function() HoverPlayer() end},
            },
        },
        Extrapos = {
            Tow = { -- fourrière
                Pos = {
                    {x=-41.63,y=-1683.18,z=29.43}
                },
                Enter = EnterZoneTow,
                Exit = ExitZoneTow,
                zonesize = 1.5,
                Blips = {
                    sprite = 473,
                    color = 81,
                    name = "Fourrière",
                },
                Marker = {
                    type = 1,
                    scale = {x=1.5,y=1.5,z=0.2},
                    color = {r=255,g=255,b=255,a=120},
                    Up = false,
                    Cam = false,
                    Rotate = false,
                    visible = true
                }
            },
            LsCustom = {
                Pos = {
                    {x=-211.63,y=-1323.18,z=30.89}
                },
                Enter = function()
                    EnterZoneLSC()
                end,
                Exit = function()
                    ExitZoneLSC()
                end,
                zonesize = 5.5,
                Blips = {
                    sprite = 72,
                    color = 81,
                    name = "LSCustoms",
                },
                Marker = {
                    type = 25,
                    scale = {x=5.5,y=5.5,z=0.2},
                    color = {r=255,g=255,b=255,a=120},
                    Up = false,
                    Cam = false,
                    Rotate = false,
                    visible = true
                }
            }
        },
        stockages = {
            coffremechanics1 = { -- fourrière
                Pos = {
                    {x=-46.52,y=-1682.81,z=29.43}
                },
                zonesize = 1.5,
                maxWeight = 15,
                Marker = {
                    type = 1,
                    scale = {x=1.5,y=1.5,z=0.2},
                    color = {r=255,g=255,b=255,a=120},
                    Up = false,
                    Cam = false,
                    Rotate = false,
                    visible = true
                }
            }
        },
        Storage = {
            {
                Pos = {x=-227.91,y=-1327.8,z=29.89},
                Limit = 500,
                Name = "coffre_mécano"
            }
        },
    },

    concess = {     
        label = "Concessionnaire",
        label2 = "Concessionnaire",
        grade = {
            {
                label = "Employé",
                salary = 75,
                name = "employe",
                show = true                
            },
            {
                label = "Manager",
                salary = 125,
                name = "manager",
                show = true                
            },
            {
                label = "C.E.O",
                salary = 200,
                name = "boss",
                show = true                
            }
        },
        Menu = {
            menu = {
                title = "Concessionnaire",
                subtitle = "Actions disponibles",
                name = "Concessionnaire_menuperso"
            },

            buttons = {
                {label="Facture",onSelected=function() CreateFacture("concess") end,ActiveFct=function() HoverPlayer() end},
            },
        },
        Storage = {
            {
                Pos = {x=-27.86,y=-1103.9,z=26.42},
                Limit = 200,
                Name = "coffre_concess"
            },
        },
    },

    immo = {     
        label = "Agent Immobilier",
        grade = {
            {
                label = "Employé",
                salary = 35,
                name = "employe",
                show = true                
            }
        },
    },

    unicorn = {     
        label = "Unicorn",
        label2 = "Vanilla Unicorn",
        grade = {
            {
                label = "Stagiaire",
                salary = 5,
                name = "stagiaire",
                show = true              
            },
            {
                label = "Employé",
                salary = 10,
                name = "employe",
                show = true              
            },
            {
                label = "Employé Confirmé",
                salary = 15,
                name = "employec",
                show = true              
            },
            {
                label = "Manager",
                salary = 20,
                name = "manager",
                show = true              
            },
            {
                label = "C.E",
                salary = 25,
                name = "ce",
                show = true              
            },
            {
                label = "C.E.O",
                salary = 30,
                name = "boss",
                show = true              
            },
        },
        Menu = {
            menu = {
                title = "Vanilla Unicorn",
                subtitle = "Actions disponibles",
                name = "Unicorn_menuperso"
            },

            buttons = {
                {label="Facture",onSelected=function() CreateFacture("Unicorn") end,ActiveFct=function() HoverPlayer() end},
            },
        },
        Storage = {
            {
                Pos = {x=93.36,y=-1291.54,z=29.27},
                Limit = 200,
                Name = "coffre_unicorn"
            },
        },
    },
}
