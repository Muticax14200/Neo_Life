local Blips = {
    {name="Commissariat", color=29, sprite=60,size=1.0, Pos = {x=428.4,y=-983.3,z=30.71}},
    {name="Unicorn", color=61, sprite=121, Pos = {x=119.47,y=-1308.58,z=29.71}},
    
    {name="Banque", color=2, sprite=434, Pos = {x=-2964.76, y=482.658, z=15.7068}},
	{name="Banque", color=2, sprite=434, Pos = {x=260.232, y=205.886, z=106.284}},
	{name="Banque", color=2, sprite=434, Pos = {x=150.061, y=-1039.99, z=29.3778}},
	{name="Banque", color=2, sprite=434, Pos = {x=-1213.57, y=-328.829, z=37.7908}},
    {name="Banque", color=2, sprite=434, Pos = {x=-109.453, y=6464.05, z=31.6267}},

    {name="Location", color=9, sprite=225, Pos = {x=-1017.87, y=-2697.18, z=13.98}},

    {name="Hôpital", color = 5, sprite=61, Pos = {x=344.04, y=-586.18, z=97.98}},
    {name="Mécano", color = 3, sprite=402, Pos = {x=-211.63,y=-1323.18,z=30.89}},
    {name="Taxi", color = 5, sprite=198, Pos = {x=909.18, y=-179.6, z=74.17}},
}

Citizen.CreateThread(function()
    for i = 1 , #Blips , 1 do
        local v = Blips[i]
        local blip = AddBlipForCoord(v.Pos.x, v.Pos.y, v.Pos.z)
        SetBlipSprite (blip, v.sprite)
        SetBlipDisplay(blip, 4)
        SetBlipScale  (blip, v.size or 0.8)
        SetBlipColour (blip,  v.color)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(v.name)
        EndTextCommandSetBlipName(blip)
    end
end)