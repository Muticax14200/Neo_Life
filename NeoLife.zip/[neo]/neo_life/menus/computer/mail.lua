Citizen.CreateThread(function()
    while true do
        Wait(1)
       
        if RageUI.Visible(RMenu:Get('computer', 'list_mail')) then
            RageUI.DrawContent({ header = false, glare = false }, function()
                if #CurrentSession.mail ~= 0 then
                    for i = 1 , #CurrentSession.mail,1 do
                        RageUI.Button("Message N°"..CurrentSession.mail[i].id,"Expéditeur : ~b~".. CurrentSession.mail[i].expeditor .."~s~\n" ..CurrentSession.mail[i].message ,{},true,function(_,_,Selected)
                            if Selected then
                                IndexMessage = i
                            end
                        end,RMenu:Get('computer', 'manage_mail'))
                    end
                else
                    RageUI.Button("Vide",nil,{},true,function(_,_,Selected)
                    end)
                end
            end, function()
            end)
        end
        
        if RageUI.Visible(RMenu:Get('computer', 'manage_mail')) then
            RageUI.DrawContent({ header = false, glare = false }, function()
                RageUI.Button("Transférer",nil,{},true,function(_,_,Selected)
                    if Selected then
                        local mailTo = KeyboardInput("Email du destinataire (50 caractère maximum !)",nil,50)
                        if tostring(mailTo) ~= nil then
                            TriggerServerEvent("mail:AddMail",mailTo,CurrentSession.mail[IndexMessage].message,CurrentSession.username.."@lifeinvader.com")
                        end
                        Wait(500)
                        RefreshMail()
                        RageUI.GoBack()
                    end
                end,RMenu:Get('computer', 'list_mail'))
                RageUI.Button("Supprimer",nil,{},true,function(_,_,Selected)
                    if Selected then
                        TriggerServerEvent("mail:DeleteFromId",CurrentSession.mail[IndexMessage].id)
                        Wait(500)
                        RefreshMail()
                        RageUI.GoBack()
                    end
                end,RMenu:Get('computer', 'list_mail'))
            end, function()
            end)
        end
        if RageUI.Visible(RMenu:Get('computer', 'mail')) then
            RageUI.DrawContent({ header = false, glare = false }, function()
                RageUI.Button("Adresse mail :",nil,{RightLabel="~b~"..CurrentSession.username.."@lifeinvader.com"},true,function()
                end)

                RageUI.Button("Envoyer un mail",nil,{},true,function()
                end,RMenu:Get('computer', 'send_mail'))

                RageUI.Button("Boite de reception",nil,{},true,function()
                end,RMenu:Get('computer', 'list_mail'))
            end, function()
            end)
        end

        if RageUI.Visible(RMenu:Get('computer', 'send_mail')) then
            RageUI.DrawContent({ header = false, glare = false }, function()
                RageUI.Button("Destinataire",nil,{RightLabel=SendMail.auteur},true,function(_,_,Selected)
                    if Selected then
                        SendMail.auteur = KeyboardInput("Entrez le destinataire",SendMail.auteur,30)
                    end
                end)

                RageUI.Button("Message",SendMail.message,{},true,function(_,_,Selected)
                    if Selected then
                        SendMail.message = KeyboardInput("Entrez votre message",SendMail.message,30)
                    end
                end)

                RageUI.Button("Envoyer",SendMail.message,{},true,function(_,_,Selected)
                    if Selected then
                        TriggerServerEvent("mail:AddMail",SendMail.auteur,SendMail.message,CurrentSession.username.."@lifeinvader.com")
                        SendMail = {
                            message = nil,
                            auteur = nil
                        }
                        RefreshMail()
                    end
                end,RMenu:Get('computer', 'mail'))
            end, function()
            end)
        end
    end
end)

-- idée hack
-- * Keylogger
-- * Intercepteur du mail
-- * accès a distance
-- * pc lspd & ems -> plus dur