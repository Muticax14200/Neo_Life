RMenu.Add('personnal', 'animations', RageUI.CreateSubMenu(RMenu:Get('personnal', 'main'),"Animations", "Animations disponibles"))

function StopAnimation()
    local ped = GetPlayerPed(-1);
    if ped then
        ClearPedTasks(ped);
    end
    SetEnableHandcuffs(ped, false)
end

for k,v in pairs(Animations) do

    RMenu.Add('personnal', 'animations_'..k, RageUI.CreateSubMenu(RMenu:Get('personnal', 'animations'),k, "Animations disponibles"))

end


Citizen.CreateThread(function()
    local DemarcheInd = 1
    local HumeurInd = 1
    local Demarche = {}
    for i = 1, #demarcheAnim, 1 do
        Demarche[i] = demarcheAnim[i].name
    end
    local Humor = {}
    for i = 1, #emoteList, 1 do
        Humor[i] = emoteList[i].name
    end
    while true do
        Wait(1)
        if RageUI.Visible(RMenu:Get('personnal', 'animations')) then
            RageUI.DrawContent({ header = true, glare = true }, function()
                RageUI.Button("Arrêter l'animation", nil, {
                }, true, function(Hovered, Active, Selected)
                    if Selected then
                        StopAnimation()
                    end
                end)
                RageUI.Button("Dormir/se réveiller", nil, {
                }, true, function(Hovered, Active, Selected)
                    if Selected then
                        LocalPlayer().Ragdoll = not LocalPlayer().Ragdoll
                    end
                end)
                for k,v in pairs(Animations) do
                    RageUI.Button(k,nil,{},true,function()

                    end,RMenu:Get('personnal', 'animations_'..k))
                end


                RageUI.List("Démarche", Demarche, DemarcheInd, nil, {}, true, function(Hovered, Active, Selected, Index)
                    DemarcheInd = Index
                    if Selected then
                        Citizen.CreateThread(function()
                            ped = GetPlayerPed(-1)
                            anim = demarcheAnim[Index].dict
                            ResetPedMovementClipset(ped, 0)
                            if Index ~= 1 then
                                RequestAnimSet(anim)
                                while not HasAnimSetLoaded(anim) do
                                    Citizen.Wait(100)
                                end
                                SetPedMovementClipset(ped, anim, 0)
                            end
                        end)
                    end
                end)

                RageUI.List("Humeur", Humor, HumeurInd, nil, {}, true, function(Hovered, Active, Selected, Index)
                    HumeurInd = Index
                    if Selected then
                        Citizen.CreateThread(function()
                            ped = GetPlayerPed(-1)
                            anim = emoteList[Index].dict
                            ClearFacialIdleAnimOverride(ped)
                            if Index ~= 1 then
                                SetFacialIdleAnimOverride(ped, anim, 0)
                            end
                        end)
                    end
                end)


            end, function()
            end)
        else
            for k,v in pairs(Animations) do
                if RageUI.Visible(RMenu:Get('personnal', 'animations_'..k)) then
                    RageUI.DrawContent({ header = true, glare = true }, function()
                        for i = 1 , #v, 1 do
                            RageUI.Button(v[i].name, nil, {
                            }, true, function(Hovered, Active, Selected)
                                if Selected then
                                    doAnim(v[i].anim, nil, v[i].func)
                                end
                            end)
                        end
                    end, function()
                    end)
                end
            end
        end


    end
end)


