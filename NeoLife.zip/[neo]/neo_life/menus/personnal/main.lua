RMenu.Add('personnal', 'main', RageUI.CreateMenu("Menu personnel", "Actions disponibles",10,100))

Citizen.CreateThread(function()
    
    while true do
        Wait(1)
        if RageUI.Visible(RMenu:Get('personnal', 'main')) then
            RageUI.DrawContent({ header = true, glare = true }, function()
                RageUI.Button("Inventaire",nil,{},true,function(_,_,Selected)

                end,RMenu:Get('personnal', 'inventory'))

                RageUI.Button("Animations",nil,{},true,function(_,_,Selected)

                end,RMenu:Get('personnal', 'animations'))

                RageUI.Button("Actions",nil,{},true,function(_,_,Selected)

                end,RMenu:Get('personnal', 'actions'))
                
                RageUI.Button("Paramètres",nil,{},true,function(_,_,Selected)

                end,RMenu:Get('personnal', 'settings'))
                if PlyGroup == "superadmin" then
                    RageUI.Button("Administration",nil,{},true,function(_,_,Selected)

                    end,RMenu:Get('personnal', 'admin'))
                end
            end, function()
            end)
        end
    end
end)


function OpenPersonnalMenu()
    RageUI.Visible(RMenu:Get('personnal', 'main'),not RageUI.Visible(RMenu:Get('personnal', 'main')))
end

KeySettings:Add("keyboard","F5",OpenPersonnalMenu,"menuperso")