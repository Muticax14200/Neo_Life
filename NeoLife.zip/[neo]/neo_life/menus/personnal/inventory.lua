RMenu.Add('personnal', 'inventory', RageUI.CreateSubMenu(RMenu:Get('personnal', 'main'), "Inventaire", "Objets disponibles"))

RMenu.Add('personnal', 'multi_inventory', RageUI.CreateSubMenu(RMenu:Get('personnal', 'inventory'), "Inventaire", "Actions disponibles"))

RMenu.Add('personnal', 'actions_1', RageUI.CreateSubMenu(RMenu:Get('personnal', 'inventory'), "Inventaire", "Actions disponibles"))

RMenu.Add('personnal', 'actions_2', RageUI.CreateSubMenu(RMenu:Get('personnal', 'multi_inventory'), "Inventaire", "Actions disponibles"))

Inventory = setmetatable({Weight=0}, Inventory)

local Infos = {
    ["permis-conduire"] = function()
        RageUI.Popup({message = "Nombre de points : ~b~".. Inventory.SelectedItem.data.points.."\n~s~Numéro de permis : ~b~" .. Inventory.SelectedItem.data.uid })
    end,
    ["kevlar"] = function()
        RageUI.Popup({message="Status du kevlar ~b~"..Inventory.SelectedItem.data.status/2 .."%"})
    end,

    ["identity"] = function()
        RageUI.Popup({message="Prénom : ~b~"..Inventory.SelectedItem.data.identity.first_name .."\n~s~Nom : ~b~" .. Inventory.SelectedItem.data.identity.last_name .. "\n~s~DDN : ~b~" .. Inventory.SelectedItem.data.identity.birth_date .. "\n~s~LDN : ~b~"..Inventory.SelectedItem.data.identity.origine})
    end
}

local Objsupp = {
    ["chaise"] = function()
       DeleteChaise()
    end,

    ["armoire"] = function()
       DeleteArmoire()
    end,

    ["fauteuil"] = function()
       DeleteFauteuil()
    end,

    ["commode"] = function()
       DeleteCommode()
    end,

    ["tablefbi"] = function()
       DeleteTablefbi()
    end
}

function tableCount(tbl, checkCount)
    if not tbl or type(tbl) ~= "table" then
        return not checkCount and 0
    end
    local n = 0
    for k, v in pairs(tbl) do
        n = n + 1
        if checkCount and n >= checkCount then
            return true
        end
    end
    return not checkCount and n
end
GetPlayers = function()
    local players = {}

    for _,player in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(player)

        if DoesEntityExist(ped) then
            table.insert(players, player)
        end
    end

    return players
end
function GetPlayerServerIdInDirection(range)
    local players, closestDistance, closestPlayer = GetPlayers(), -1, -1
    local coords, usePlayerPed = coords, false
    local playerPed, playerId = PlayerPedId(), PlayerId()

    if coords then
        coords = vector3(coords.x, coords.y, coords.z)
    else
        usePlayerPed = true
        coords = GetEntityCoords(playerPed)
    end

    for i=1, #players, 1 do
        local target = GetPlayerPed(players[i])
            if not usePlayerPed or (usePlayerPed and players[i] ~= playerId) then
                local targetCoords = GetEntityCoords(target)
                local distance = #(coords - targetCoords)

                if closestDistance == -1 or closestDistance > distance then
                    closestPlayer = players[i]
                    closestDistance = distance
                end
            end
    end

    if closestDistance > 7.0 or closestDistance == -1 then
        closestPlayer = nil
    end

    return closestPlayer ~= nil and GetPlayerServerId(closestPlayer) or false
end
function CastRayPlayerPedToPoint(range, type)

    local playerPed = GetPlayerPed()
    local playerCoords = LocalPlayer().Position
    local entityWorld = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, range, 0.0)
    local rayHandle = StartShapeTestRay(playerCoords.x, playerCoords.y, playerCoords.z, entityWorld.x, entityWorld.y, entityWorld.z, type, playerPed, 0)
    local a, b, c, d, entity = GetRaycastResult(rayHandle)
    if entity ~= nil then
        return entity
    end
    return false

end

function GetEntityInDirection(range)

    if type(range) ~= "number" then
        range = 20.0
    end
    return CastRayPlayerPedToPoint(range, 10)

end

function GetPedInDirection(range)
    if type(range) ~= "number" then
        range = 20.0
    end
    local entity = GetEntityInDirection(range)
    if DoesEntityExist(entity) then
        if GetEntityType(entity) == 1 then
            return entity
        end
    end
    return false
end

function Inventory:Load()
    TriggerServerCallback('getInventory', function(Data)
        self.Data = Data
        self:Format()
    end)
end
function Inventory.canReceive(name,amount)
    return Inventory.CanReceive(name,amount)
end
function Inventory.CanReceive(name,am)
    return Inventory.CanReceive(name,am)
end
function Inventory.CanReceive(_name,amount)
    Inventory:RefreshWeight()
    local tempWeight = Inventory.Weight
    tempWeight = tempWeight + (Items[_name].weight*amount)

    if tempWeight >= 40 then
        RageUI.Popup({ message = "~r~Vous n'avez plus assez de place" })
        return false
    else
        return true
    end
end
function GetNuMale()
    return {
        torso = { id = 15, txt = 0 },
        undershirt = { id = 15, txt = 0 },
        tops = { id = 15, txt = 0 },
        body_armor = { id = 0, txt = 0 },
        backpacks = { id = 0, txt = 0 },
        texture = { id = 0, txt = 0 },
        feet = { id = 34, txt = 0 },
        legs = { id = 14, txt = 0 },
        accessories = { id = 0, txt = 0 },
        mask = { toggle = false, id = 0, txt = 0 },
        hat = { toggle = false, id = -1, txt = 0 },
        glasses = { toggle = false, id = -1, txt = 0 },
        ears = { toggle = false, id = -1, txt = 0 },
        watches = { toggle = false, id = -1, txt = 0 },
        bracelets = { toggle = false, id = -1, txt = 0 },
    }
end
function GetNuFemale()
    return {
        torso = { id = 15, txt =  0  },
        undershirt = { id = 15, txt = 0 },
        tops = { id = 15, txt = 0 },
        body_armor = { id = 0, txt = 0 },
        backpacks = { id = 0, txt = 0 },
        texture = { id = 0, txt = 0 },
        feet = { id = 35, txt = 0 },
        legs = { id = 21, txt =0},
        accessories = { id = 0, txt = 0 },
        mask = { toggle = false, id = 0, txt = 0 },
        hat = { toggle = true, id = -1, txt = 0 },
        glasses = { toggle = true, id = -1, txt = 0 },
        ears = { toggle = true, id = -1, txt = 0 },
        watches = { toggle = true, id = -1, txt = 0 },
        bracelets = { toggle = true, id = -1, txt = 0 },
    }
end
function RefreshClothes()
    local clothesIn = Inventory.Inventory["clothe"]
    local accessIn = Inventory.Inventory["access"]
    local Clothes = {}
    if isMale() then   
        Clothes =  GetNuMale()
    else
        Clothes = GetNuFemale()
    end


    UpdateEntityOutfit(GetPlayerPed(-1),Clothes)
    if clothesIn ~= nil then
        for i = 1 , #clothesIn, 1 do
            if clothesIn[i].data.equiped then
                if clothesIn[i].data.type == 0 then
                    SetPedComponentVariation(GetPlayerPed(-1), clothesIn[i].data.component, clothesIn[i].data.var, clothesIn[i].data.ind)
                    if clothesIn[i].data.component == 11 then
                        SetPedComponentVariation(GetPlayerPed(-1), 8,clothesIn[i].data.h,clothesIn[i].data.hV, 2)
                        SetPedComponentVariation(GetPlayerPed(-1), 3, clothesIn[i].data.bras)
                    end
                end
            end
        end
    end
    if accessIn ~= nil then
        for i = 1 , #accessIn, 1 do
            if accessIn[i].data.equiped then
                SetPedPropIndex(GetPlayerPed(-1), accessIn[i].data.component, accessIn[i].data.var, accessIn[i].data.ind,2)
            end
        end
    else

    end
end
function Inventory:Format()
    self.Inventory = {}
    for i = 1, #self.Data, 1 do
        local p = self.Data[i]
        if self.Inventory[p.name] == nil then
            self.Inventory[p.name] = {}
        end
        local c = self.Inventory[p.name]
        local data = p.data ~= nil and json.decode(p.data) or nil
        table.insert(c, { name = p.name, data = data, label = p.label, id = p.id })
    end
    RefreshClothes()
    self:RefreshWeight()
end

function Inventory:Delete()
    Inventory:RemoveItemToInv(Inventory.SelectedItem.id,Inventory.SelectedItem.name)
    TriggerServerEvent("inventory:RemoveItem",Inventory.SelectedItem.id,Inventory.SelectedItem.name)
    RageUI.GoBack()
    RageUI.GoBack()
    RageUI.GoBack()
end
function Inventory:UseItem()
    if  Items[self.SelectedItem.name].category == "weapon" then
        EquipWeapon()
    elseif Items[self.SelectedItem.name].category == "food" then
        TriggerEvent("miam:Drink",self.SelectedItem,Items)
        Inventory:Delete()
    else
        if Items[self.SelectedItem.name].actionCl ~= nil and ItemsFunction[self.SelectedItem.name] == nil then
            TriggerEvent(Items[self.SelectedItem.name].actionCl, self.SelectedItem)
        elseif Items[self.SelectedItem.name].action and ItemsFunction[self.SelectedItem.name] == nil then
            TriggerServerEvent(Items[self.SelectedItem.name].action, self.SelectedItem)
        else
            --(dump(ItemsFunction))
            --(self.SelectedItem.name)
            --(ItemsFunction[self.SelectedItem.name])
            if ItemsFunction[self.SelectedItem.name] ~= nil then
                ItemsFunction[self.SelectedItem.name]()

            else
                ShowAboveRadarMessage("~r~Vous ne pouvez pas utiliser cet objet")
            end
        end
    end
end
local armed = false
Citizen.CreateThread(function()
	while true do
        Citizen.Wait(1000)
        found = false
		pp = GetSelectedPedWeapon(GetPlayerPed(-1))
        if pp ~= GetHashKey("WEAPON_Unarmed") then
            armed = true
            for k,v in pairs(weapon_name) do  
                Wait(200)   
                if GetHashKey(v) == pp then      
                    if Inventory.Inventory[k] ~= nil and #Inventory.Inventory[k] == 0 then                      
                        RemoveWeaponFromPed(GetPlayerPed(-1),pp)       
                    elseif Inventory.Inventory[k] == nil then
                        RemoveWeaponFromPed(GetPlayerPed(-1),pp)                 
                    end
					
				end
            end
            Wait(1000)
        else
            armed = false
        end
		Wait(10)
	end
end)
combatM = nil
--Citizen.CreateThread(function()
--	while true do
--        Citizen.Wait(1)
--        if (armed) then
--            SetFollowPedCamViewMode(4)
--            HideHudComponentThisFrame(14)
--            SetPedSuffersCriticalHits(GetPlayerPed(-1), false)
--            combatM = true
--        else
--            combatM = false
--        end
--    end
--end)
local inventoryFilter = {
    Index = 1,
    Label = {"Aucun","Nourriture","Arme","Vêtements"},
    Filter = {nil,"food","weapon","clothes"},
    count = 0
}
function Inventory:GiveItem()
    player = GetPlayerServerIdInDirection(5.0)
    if (player ~= false) then
        count = KeyboardInput("~b~Combien ?", nil, 25)
        count = tonumber(count)
        if count ~= nil and self:GetItemCount(self.SelectedItem.name) >= count then
            local giveTable = {}
            for i = 1, count, 1 do
                k = self.Inventory[self.SelectedItem.name]
                if k.id == self.SelectedItem.id then
                    if self.SelectedItem.data ~= nil and self.SelectedItem.data.equiped ~= nil then
                        self.SelectedItem.data.equiped = false
                    end
                    table.insert(giveTable, self.SelectedItem)
                else
                    if self.Inventory[self.SelectedItem.name][i].data ~= nil and self.Inventory[self.SelectedItem.name][i].data.equiped ~= nil then
                        self.Inventory[self.SelectedItem.name][i].data.equiped = false
                    end
                    table.insert(giveTable, self.Inventory[self.SelectedItem.name][i])
                end
            end
            for i = 1 ,#giveTable , 1 do
                Inventory:RemoveItemToInv(giveTable[i].id,giveTable[i].name)
            end
            
            TriggerServerEvent("inventory:giveOtherPlayer", giveTable, player)
            giveTable = {}
        else
            RageUI.Popup({ message = "~r~Vous n'avez pas assez de " .. Items[self.SelectedItem.name].label })
        end
    else
        RageUI.Popup({ message = "~r~Aucun joueurs proche" })
    end
end

function Inventory:GetItemCount(item)
    found = 0
	if self.Inventory ~= nil then
		for k, v in pairs(self.Inventory) do
			if k == item then
				if #v <= 0 then
					found = 0
				else
					found = #v
				end
			end
		end
	end
		return found

end
Inventory.CurrentWeapon = {
    Label = nil,
    Name = nil
}
function Inventory:RemoveItemToInv(id,item)
    print("deleting :" ,id, item)

    for k, px in pairs(self.Inventory) do
        local t = px
        if k == item then
            for i = 1, #px, 1 do
                if px[i].id == id then
                    if item == "tel" then
                        if px[i].data.num == MyNumber then
                            MyNumber = 0
                            MyBattery = 0
                            TriggerEvent("gcphone:UpdateBattery",MyBattery)
                            TriggerEvent("gcPhone:myPhoneNumber",MyNumber)
                            TriggerServerEvent('gcPhone:allUpdate')
                        end
                    end
                    table.remove(self.Inventory[item], i)
                    if item == "clothe" then
                        RefreshClothes()
                    end
                    break
                end
            end
        end
    end
    self:RefreshWeight()
end

function Inventory:AddItemToInv(item, id, data, label)
    RageUI.Popup({message="Vous avez reçu ~b~"..string.lower(Items[item].label)})
    if self.Inventory == nil then
        self.Inventory =  {}
    end
    if self.Inventory[item] == nil then
        self.Inventory[item] = {}
    end
    T = self.Inventory[item]
    local cp = nil
    for k, v in pairs(weapon_name) do
        if v == Inventory.CurrentWeapon.Label then
            cp = k
        end
    end
    if item == weapon_munition[cp] then
        AddAmmoToPed(GetPlayerPed(-1), Inventory.CurrentWeapon.Name, 1)
    end
    table.insert(T, { name = item, id = id, data = data, label = label })
    self:RefreshWeight()
end
function Inventory.addItem()
    return Inventory:AddItem()
end
function Inventory:AddItem()
    TriggerServerEvent("inventory:AddItem", Inventory.SelectedItem)
    self:RefreshWeight()
end
function Inventory.removeItem(id,name)
    Inventory:RemoveItemToInv(id,name)
    TriggerServerEvent("inventory:RemoveItem", id,name)
    Inventory:RefreshWeight()
end
function Inventory:RemoveItem(p,k)
    if p == nil then p = Inventory.SelectedItem.id end
    if k == nil then k = Inventory.SelectedItem.name end
    return Inventory.removeItem(p,k)
end
function Inventory:RefreshWeight()
    self.Weight = 0
    if self.Inventory ~= nil then
        for k, v in pairs(self.Inventory) do
            if v[1] ~= nil then
                p = self.Inventory[k]
                self.Weight = self.Weight + (Items[v[1].name].weight*#v)
            end
        end
        TriggerServerEvent("inventory:UpdateWeight", self.Weight)
        RMenu:Get('personnal', 'inventory'):SetPageCounter(math.floor(self.Weight, 2) .. "/40KG") 

    end
end

function Inventory:Infos()
    if Infos[Inventory.SelectedItem.name] ~= nil then
        Infos[Inventory.SelectedItem.name]()
    end
end

function Inventory:Objsupp()
    if Objsupp[Inventory.SelectedItem.name] ~= nil then
        Objsupp[Inventory.SelectedItem.name]()
    end
end

function Inventory:Rename()
    label = KeyboardInput("~b~Renommer l'item", self.SelectedItem.label, 25)
    if label ~= self.SelectedItem.rename then
        TriggerServerCallback('inventory:renameItem', function(cb)
            if cb == true then
                for k, px in pairs(self.Inventory) do
                    if k == self.SelectedItem.name then
                        for i = 1, #px, 1 do
                            if px[i].id == self.SelectedItem.id then
                                px[i].label = label
                            end
                        end
                    end
                end
            end
        end, self.SelectedItem.id, label)
    end
end

RegisterNetEvent("inventory:removeItem")
AddEventHandler("inventory:removeItem", function(id,name)

    Inventory:RemoveItemToInv(id,name)

end)
RegisterNetEvent("inventory:AddItem2")
AddEventHandler("inventory:AddItem2", function(item)
    print('add ',dump(item))

end)
RegisterNetEvent("inventory:AddItem")
AddEventHandler("inventory:AddItem", function(item, data, label, id)
    Inventory:AddItemToInv(item.name, item.id, item.data, item.label)
end)
local currentHoverItem = nil
RMenu:Get('personnal', 'inventory'):AddInstructionButton({
    [1] = GetControlInstructionalButton(0, Keys["L"], 0),
    [2] = "Supprimer",
})
Citizen.CreateThread(function()
    while true do
        Wait(1)

        if RageUI.Visible(RMenu:Get('personnal', 'inventory')) then
            if IsControlJustPressed(0,Keys["L"]) then
                if currentHoverItem ~= nil then
                    local count = KeyboardInput("Combien ? ", nil , 3) 
                    count = tonumber(count)
                    local inventory = Inventory.Inventory
                    if count ~= nil and #inventory[currentHoverItem] - count >= 0  then
                        
                        local v = inventory[currentHoverItem]
                        local _v = v
                        local items = {}
                        for i = 1, count, 1 do
                            if _v[i] ~= nil then
                                items[i] = {id=_v[i].id,name=currentHoverItem}
                            end
                        end
                        
                        for i = 1 , #items, 1 do
                            TriggerServerEvent("inventory:RemoveItem",items[i].id,items[i].name)
                            Inventory:RemoveItemToInv(items[i].id,items[i].name)
                        end

                    end
                else
                    ShowNotification("~r~Vous n'êtes pas sur un item")
                end
            end
            RageUI.DrawContent({ header = true, glare = true }, function()
                inventoryFilter.count = 0
                RageUI.List("Filtre",inventoryFilter.Label,inventoryFilter.Index, nil,{},true,function(_,Active,Selected,Index)
                    inventoryFilter.Index = Index
                    CurrentFilter = inventoryFilter.Filter[Index]
                    if Selected then
                        local filter = KeyboardInput("Entrez un filtre",nil,250)
                        filter = tostring(filter) 
                        local found = false
                        for i = 1 , #inventoryFilter.Label ,1 do
                            if inventoryFilter.Label[i] == filter then
                                CurrentFilter = inventoryFilter.Filter[i]
                                inventoryFilter.Index = i
                                found = true
                            end
                        end
                        if tostring(filter) ~= nil and filter ~= "" and found then
                            CurrentFilter = filter
                        elseif tostring(filter) == nil and filter == "" then
                            CurrentFilter = nil
                        else
                            ShowAboveRadarMessage("Filtre ~r~invalide")
                        end
                    end
                end)
                if tableCount(Inventory.Inventory) == 0 then
                    RageUI.Button("Vide", nil, {}, true, function(_, _, _)
                    end)
                else
                    currentHoverItem = nil
                    for k, v in pairs(Inventory.Inventory) do
                        if CurrentFilter == nil or Items[k].category == CurrentFilter then
                            if #v > 0 then
                                inventoryFilter.count = inventoryFilter.count + 1
                                if #v == 1 then
                                    RageUI.Button(v[1].label ~= nil and Items[k].label .. " '" .. v[#v].label .. "'" or Items[k].label, nil, { RightLabel = 1 }, true, function(_, Active, Selected)
                                        if Selected then
                                            Inventory.SelectedItem = v[1]
                                        end
                                        if Active then
                                            currentHoverItem = k
                                        end
                                    end, RMenu:Get('personnal', 'actions_1'))
                                else
                                    RageUI.Button(Items[k].label, nil, { RightLabel = #v .. "→" }, true, function(_, A, Selected)
                                        if Selected then
                                            Inventory.Selected = v
                                        end

                                        if A then
                                            currentHoverItem = k
                                        end
                                    end, RMenu:Get('personnal', 'multi_inventory'))
                                end
                            end
                        end
                    end
                    if inventoryFilter.count == 0 then
                        RageUI.Button("Vide", nil, {}, true, function()
                        end)
                    end
                end

            end, function()
            end)
        end

        if RageUI.Visible(RMenu:Get('personnal', 'multi_inventory')) then
            RageUI.DrawContent({ header = true, glare = true }, function()
                for i = 1, #Inventory.Selected, 1 do
                    RageUI.Button(Inventory.Selected[i].label ~= nil and Items[Inventory.Selected[i].name].label .. " '" .. Inventory.Selected[i].label .. "'" or Items[Inventory.Selected[i].name].label, nil, { RightLabel = 1 }, true, function(_, _, Selected)
                        if Selected then
                            Inventory.SelectedItem = Inventory.Selected[i]
                        end
                    end, RMenu:Get('personnal', 'actions_2'))
                end
            end, function()
            end)
        end

        if RageUI.Visible(RMenu:Get('personnal', 'actions_1')) or RageUI.Visible(RMenu:Get('personnal', 'actions_2')) then
            RageUI.DrawContent({ header = true, glare = true }, function()

                RageUI.Button("Utiliser", nil, {}, true, function(_, _, Selected)
                    if Selected then
                        Inventory:UseItem()
                    end
                end)

                RageUI.Button("Renommer", nil, {}, true, function(_, _, Selected)
                    if Selected then
                        Inventory:Rename()
                    end
                end)

                RageUI.Button("Donner", nil, {}, true, function(_, A, Selected)
                    if Selected then
                        Inventory:GiveItem()
                    end
                    if A  then
                        HoverPlayer()
                    end
                end)

                RageUI.Button("~r~Supprimer", nil, {}, true, function(_, _, Selected)
                    if Selected then
                        -- Inventory:Throw()
                        Inventory:Delete()
                    end
                end)
                if Objsupp[Inventory.SelectedItem.name] ~= nil then
                    RageUI.Button("Enlever objet", nil, {}, true, function(_, _, Selected)
                        if Selected then
                            Inventory:Objsupp()
                        end
                    end)
                end
                if Infos[Inventory.SelectedItem.name] ~= nil then
                    RageUI.Button("Informations", nil, {}, true, function(_, _, Selected)
                        if Selected then
                            Inventory:Infos()
                        end
                    end)
                end

            end, function()
            end)
        end
    end
end)

RegisterCommand("loadinv", function()
    
end)




