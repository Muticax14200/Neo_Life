function CreatorMenuRoleplay(indexCharacter, createPlayer)
    RageUI.DrawContent({ header = true, instructionalButton = true }, function()

        RageUI.Button("Prénom", "Inscrivez votre ~o~prénom.", { RightLabel = createPlayer[createPlayer.Model].Identity.first_name }, true, function(Hovered, Active, Selected)
            if Selected then
                createPlayer[createPlayer.Model].Identity.first_name = KeyboardInput("~b~Prénom", "", 25)
            end
        end)

        RageUI.Button("Nom", "Inscrivez votre ~o~nom.", { RightLabel = createPlayer[createPlayer.Model].Identity.last_name }, true, function(Hovered, Active, Selected)
            if Selected then
                createPlayer[createPlayer.Model].Identity.last_name = KeyboardInput("~b~Nom", "", 25)
            end
        end)

        RageUI.Button("Date de naissance", "Inscrivez votre ~o~date de naissance.", { RightLabel = createPlayer[createPlayer.Model].Identity.birth_date }, true, function(Hovered, Active, Selected)
            if Selected then
                createPlayer[createPlayer.Model].Identity.birth_date = KeyboardInput("~b~Date de naissance", "JJ/MM/AAAA", 25)
            end
        end)

        RageUI.Button("Lieu de naissance", "Inscrivez votre ~o~lieu de naissance.", { RightLabel = createPlayer[createPlayer.Model].Identity.origine }, true, function(Hovered, Active, Selected)
            if Selected then
                createPlayer[createPlayer.Model].Identity.origine = KeyboardInput("~b~lieu de naissance", "", 25)
            end
        end)

    end, function()
        ---Panels
    end)
end