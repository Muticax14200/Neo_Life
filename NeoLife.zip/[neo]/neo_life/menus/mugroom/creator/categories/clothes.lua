local MenClothes = {
    {
        Name = "Cuir noir",
        Selected = false,
        Value = {
            torso = { id = 1, txt = 0 },
            undershirt = { id = 2, txt = 2 },
            tops = { id = 6, txt = 0 },
            legs = { id = 1, txt = 1 },
            body_armor = { id = 0, txt = 0 },
            backpacks = { id = 0, txt = 0 },
            texture = { id = 0, txt = 0 },
            feet = { id = 1, txt = 0 },
            accessories = { id = 0, txt = 0 },
            mask = { toggle = false, id = 0, txt = 0 },
            hat = { toggle = false, id = -1, txt = 0 },
            glasses = { toggle = false, id = -1, txt = 0 },
            ears = { toggle = false, id = -1, txt = 0 },
            watches = { toggle = false, id = -1, txt = 0 },
            bracelets = { toggle = false, id = -1, txt = 0 },
        }
    },
    {
        Name = "Sport blanc",
        Selected = false,
        Value = {
            torso = { id = 1, txt = 0 },
            undershirt = { id = 0, txt = 2 },
            tops = { id = 7, txt = 0 },
            legs = { id = 5, txt = 0 },
            body_armor = { id = 0, txt = 0 },
            backpacks = { id = 0, txt = 0 },
            texture = { id = 0, txt = 0 },
            feet = { id = 26, txt = 0 },
            accessories = { id = 0, txt = 0 },
            mask = { toggle = false, id = 0, txt = 0 },
            hat = { toggle = false, id = -1, txt = 0 },
            glasses = { toggle = false, id = -1, txt = 0 },
            ears = { toggle = false, id = -1, txt = 0 },
            watches = { toggle = false, id = -1, txt = 0 },
            bracelets = { toggle = false, id = -1, txt = 0 },
        }
    },
    {
        Name = "Hiver rude",
        Selected = false,
        Value = {
            torso = { id = 96, txt = 0 },
            undershirt = { id = 115, txt = 1 },
            tops = { id = 191, txt = 5 },
            legs = { id = 98, txt = 1 },
            body_armor = { id = 0, txt = 0 },
            backpacks = { id = 0, txt = 0 },
            texture = { id = 0, txt = 0 },
            feet = { id = 63, txt = 4 },
            accessories = { id = 0, txt = 0 },
            mask = { toggle = false, id = 0, txt = 0 },
            hat = { toggle = false, id = -1, txt = 0 },
            glasses = { toggle = false, id = -1, txt = 0 },
            ears = { toggle = false, id = -1, txt = 0 },
            watches = { toggle = false, id = -1, txt = 0 },
            bracelets = { toggle = false, id = -1, txt = 0 },
        }
    },
    {
        Name = "Junki",
        Selected = false,
        Value = {
            torso = { id = 1, txt = 0 }, -- Top (lambda)
            undershirt = { id = 115, txt = 1 }, -- Shirt (lambda)
            tops = { id = 121, txt = 3 }, -- Shirt / Jacket (lambda)
            legs = { id = 5, txt = 2 },
            body_armor = { id = 0, txt = 0 },
            backpacks = { id = 0, txt = 0 },
            texture = { id = 0, txt = 0 },
            feet = { id = 6, txt = 0 },
            accessories = { id = 0, txt = 2 },
            mask = { toggle = false, id = 0, txt = 0 },
            hat = { toggle = false, id = -1, txt = 0 },
            glasses = { toggle = false, id = -1, txt = 0 },
            ears = { toggle = false, id = -1, txt = 0 },
            watches = { toggle = false, id = -1, txt = 0 },
            bracelets = { toggle = false, id = -1, txt = 0 },
        }
    }
}

local FemaleClothes = {
    {
        Name = "Love fist",
        Selected = false,
        Value = {
            torso = { id = 4, txt = 0 },
            undershirt = { id = 2, txt = 0 },
            tops = { id = 36, txt = 0 },
            legs = { id = 25, txt = 6 },
            body_armor = { id = 0, txt = 0 },
            backpacks = { id = 0, txt = 0 },
            texture = { id = 0, txt = 0 },
            feet = { id = 49, txt = 0 },
            accessories = { id = 0, txt = 0 },
            mask = { toggle = false, id = 0, txt = 0 },
            hat = { toggle = false, id = -1, txt = 0 },
            glasses = { toggle = true, id = 8, txt = 0 },
            ears = { toggle = false, id = -1, txt = 0 },
            watches = { toggle = true, id = 16, txt = 0 },
            bracelets = { toggle = false, id = -1, txt = 0 },
        }
    },
    {
        Name = "Hiver rude",
        Selected = false,
        Value = {
            torso = { id = 49, txt = 1 },
            undershirt = { id = 2, txt = 0 },
            tops = { id = 3, txt = 0 },
            legs = { id = 4, txt = 9 },
            body_armor = { id = 0, txt = 0 },
            backpacks = { id = 0, txt = 0 },
            texture = { id = 0, txt = 0 },
            feet = { id = 2, txt = 1 },
            accessories = { id = 2, txt = 5 },
            mask = { toggle = false, id = 0, txt = 0 },
            hat = { toggle = true, id = 12, txt = 0 },
            glasses = { toggle = true, id = 17, txt = 0 },
            ears = { toggle = false, id = -1, txt = 0 },
            watches = { toggle = false, id = -1, txt = 0 },
            bracelets = { toggle = false, id = -1, txt = 0 },
        }
    },
    {
        Name = "Junkie",
        Selected = false,
        Value = {
            torso = { id = 4, txt = 0 },
            undershirt = { id = 2, txt = 0 },
            tops = { id = 169, txt = 0 },
            legs = { id = 78, txt = 1 },
            body_armor = { id = 0, txt = 0 },
            backpacks = { id = 0, txt = 0 },
            texture = { id = 0, txt = 0 },
            feet = { id = 3, txt = 0 },
            accessories = { id = 0, txt = 0 },
            mask = { toggle = false, id = 0, txt = 0 },
            hat = { toggle = true, id = 82, txt = 1 },
            glasses = { toggle = false, id = -1, txt = 0 },
            ears = { toggle = false, id = -1, txt = 0 },
            watches = { toggle = true, id = 17, txt = 0 },
            bracelets = { toggle = true, id = 14, txt = 0 },
        }
    },
    {
        Name = "Street",
        Selected = false,
        Value = {
            torso = { id = 6, txt = 0 },
            undershirt = { id = 0, txt = 0 },
            tops = { id = 106, txt = 0 },
            legs = { id = 3, txt = 0 },
            body_armor = { id = 0, txt = 0 },
            backpacks = { id = 0, txt = 0 },
            texture = { id = 0, txt = 0 },
            feet = { id = 27, txt = 0 },
            accessories = { id = 0, txt = 0 },
            mask = { toggle = false, id = 0, txt = 0 },
            hat = { toggle = true, id = 3, txt = 9 },
            glasses = { toggle = false, id = -1, txt = 0 },
            ears = { toggle = false, id = -1, txt = 0 },
            watches = { toggle = false, id = -1, txt = 0 },
            bracelets = { toggle = false, id = -1, txt = 0 },
        }
    }
}

local SelectedClothes = {
    mp_m_freemode_01 = {
        Index = 0,
    },
    mp_f_freemode_01 = {
        Index = 0,
    }
}

local function SelectedClothesWithModel()
    if (GetEntityModel(GetPlayerPed(-1)) == GetHashKey('mp_m_freemode_01')) then
        return MenClothes
    else
        return FemaleClothes
    end
end

local function EquipedClothesBadge(Index, Key)
    if (Key == Index) then
        return { RightBadge = RageUI.BadgeStyle.Clothes }
    else
        return {  }
    end
end


function CreatorMenuClothes(indexCharacter, createPlayer)
    RageUI.DrawContent({ header = true, instructionalButton = true }, function()
        for k, v in pairs(SelectedClothesWithModel()) do
            RageUI.Button(v.Name, v.Description, EquipedClothesBadge(SelectedClothes[createPlayer.Model].Index, k), true, function(Hovered, Active, Selected)
                if Selected then
                    SelectedClothes[createPlayer.Model].Index = k
                    local Entity = GetPlayerPed(-1)
                    UpdateEntityOutfit(Entity, v.Value)
                    if not (isPlayingAnimSelectedClothes(Entity)) then
                        OnSelectedClothes(v.Value)
                    end
                end
            end)
        end
    end, function()

    end)
end