local KeyList = {
    ["F5"] = "Menu personnel",
    ["F2"] = "Téléphone",
    ["F6"] = "Menu métier",
    ["V"] = "Changer de vue",
}

local function chatMessage(msg)
    TriggerEvent("chatMessage", "NEO", {2,187,249}, msg)
end