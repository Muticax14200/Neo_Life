vcf_files = {
	"POLICE.xml",
	"POLICE2.xml",
	"POLICE3.xml",
	"POLICE4.xml",
	"POLICE5.xml",
	"POLICE6.xml",
	"POLICE7.xml",
	"POLICE8.xml",
	"POLICE9.xml",
	"POLICET.xml",
	"RIOT.xml",
}