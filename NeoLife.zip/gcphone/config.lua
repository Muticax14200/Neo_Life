FixePhone = {
  -- Cabine proche du poste de police
  --['008-0001'] = { name = "Cabine Telephonique", coords = { x = 372.25, y = -965.75, z = 28.58 } },
}

ShowNumberNotification = false