ip = GetConvar('es_couchdb_url', '127.0.0.1')
port = GetConvar('es_couchdb_port', '5984')
auth = GetConvar('es_couchdb_password', 'root:1202')