fx_version 'bodacious'
games { 'rdr3', 'gta5' }

server_scripts {
	'config.lua',
	'server/main.lua'
}


client_scripts {
	'config.lua',
	'client/main.lua'
}
