fx_version "adamant"
game "gta5"

ui_page "index.html"

dependencies {
	"neo_voice",
}

files {
	"index.html",
	"on.ogg",
	"off.ogg",
}

client_scripts {
	"config.lua",
	"client.lua",
}

server_scripts {
	"server.lua",
}